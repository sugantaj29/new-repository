<?php
/**
 * Template Name: Contact
 */

get_header(); ?>

<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>

<section class="map">
  <div class="map-content">
    <iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d1816.567934777919!2d54.46062455902865!3d24.41134690087195!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sZayed%20Sports%20City%20Football%20Stadium%20Gate%2040%20Abu%20Dhabi%20Po%20Box%3A%203363%20UAE.!5e0!3m2!1sen!2sin!4v1569407926686!5m2!1sen!2sin" frameborder="0" style="border:0" allowfullscreen></iframe>
  </div>
  <section class="inner-banner-contact slideuppanel" style="background:url('<?php echo $featureimg ?>') no-repeat scroll center center /cover	;"> <div class="container"><div class="banner-caption"><p><?php the_title();?></p></div></div></section>
</section>
<section class="solutions-section grey slidedownpanel"> 
  <!-- services section -->
  <div class="container">
    <div class="row">
      <button class="map-open"></button>
    </div>
  </div>
</section>
<section class="contact_section">
<div class="container">
<div class="row">
<div class="col-md-3 col-sm-3 col-xs-12 address">
<div class="wow animated zoomIn">
<?php the_content();?>
</div>
</div>
<div class="col-md-9 col-sm-9 col-xs-12 form">
<div class="row">
<h3 class="text-center">Got Questions?  We are here to help you!</h3>
</div>
<div class="form_in">
<?php echo do_shortcode('[contact-form-7 id="6" title="Contact form"]');?>
</div>
</div>
</div>
</div>
</section>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js"></script> 
<script>
var healthsoft=new google.maps.LatLng(24.4113469,54.4606246,18);


function initialize()
{
var mapProp = {
  center:niyati1,
  zoom:4,
  //mapTypeId:google.maps.MapTypeId.HYBRID
  };

var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);

var marker=new google.maps.Marker({
  position:niyati1,
  icon:'<?php bloginfo('template_url'); ?>/images/marker.png',
  });

marker.setMap(map);
marker_sing.setMap(map);
marker_dubai.setMap(map);



var info_india = new google.maps.InfoWindow({
  content:"<div class='map_address'><h3>Zayed Sports City Football Court</h3></div>"
  });
google.maps.event.addListener(marker, 'click', function() {
  info_india.open(map,marker);
  info_dubai.close();
  info_sing.close();
  });
}


google.maps.event.addDomListener(window, 'load', initialize);

jQuery(document).ready(function (jQuery) {
    //THIS MAKES THE SLIDEY THINGS SLIDE
    //textone
    if (window.matchMedia("(max-width: 767px)").matches) {
        // window width is under 663px
        jQuery(document).on('click','.map-open', function() {
    jQuery('.slideuppanel').animate({top:'-320px'}, 500);
    jQuery(this).addClass('opened');
    jQuery(this).removeClass('closed');
    jQuery('.map-content').animate({height:'500px'}, 500);
	});

	jQuery(document).on('click','.opened', function() {
    jQuery('.slideuppanel').animate({top:'0px'}, 500);
    jQuery(this).removeClass('opened');
    jQuery(this).addClass('closed');
	jQuery('.map-content').animate({height:'320px'}, 500);
  
	});

    } else {
        // window width is greater than 1366px
       jQuery(document).on('click','.map-open', function() {
    jQuery('.slideuppanel').animate({top:'-400px'}, 500);
    jQuery(this).addClass('opened');
    jQuery(this).removeClass('closed');
    jQuery('.map-content').animate({height:'600px'}, 500);
	});

	jQuery(document).on('click','.opened', function() {
    jQuery('.slideuppanel').animate({top:'0px'}, 500);
    jQuery(this).removeClass('opened');
    jQuery(this).addClass('closed');
	jQuery('.map-content').animate({height:'380px'}, 500);
  
	});
    }
});
</script>

 



<?php endwhile; // end of the loop. ?>

<?php get_footer(); ?>

