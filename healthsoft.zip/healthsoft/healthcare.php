<?php
/**
 * Template Name: Healthcare
 */

get_header(); ?>

<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>

<section class="inner-banner" style="background-image:url(<?php echo $featureimg; ?>); ">
  <div class="container">
    <div class="banner-caption">
      <h2>Services</h2>
      <p><?php the_title();?></p>
    </div>
  </div>
</section>

<section class="cycle_management healthcare">
 <div class="container">
   <div class="col-xs-12 wow animated zoomIn">
     <?php the_content();?>
   </div>
  </div>
 </section>

 <section class="healthcare-content">
 <div class="container">
   <div class="col-md-7 col-sm-6 col-xs-12">
     <?php the_field('healthcare-content')?>
   </div>
   <div class="col-md-5 col-sm-6 col-xs-12">
   <div class="blue_box">
     <h3 class="wow animated fadeIn"><?php the_field('box-content')?></h3>
     </div>
   </div>
   
 </div>
</section>



 



<?php endwhile; // end of the loop. ?>


<?php get_footer(); ?>
<style>


@media screen and (max-width: 767px){
  
}

</style>
