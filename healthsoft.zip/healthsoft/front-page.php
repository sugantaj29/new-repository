<?php
/**
* Template Name: Front page
 */

get_header(); ?>

<!--page contentrs starts here-->
<main class="page_template">
<!-- banner section -->

<section class="banner_section">
  <div class="flexslider">
    <ul class="slides">
      <?php
if( have_rows('banner') ):
while ( have_rows('banner') ) : the_row(); ?>
      <li>
        <div class="banner" style="background-image:url(<?php the_sub_field('image')?>);background-size:cover;background-repeat:no-repeat;background-position:center center;width:100%;min-height:647px;">
          <div class="container">
            <div class="caption">
              <h2>
                <?php the_sub_field('title')?>
              </h2>
              <div>
                <?php the_sub_field('content')?>
              </div>
              <a href="<?php the_sub_field('link')?>" class="home-read-more">Read more</a> </div>
          </div>
        </div>
      </li>
      <?php endwhile; endif; ?>
    </ul>
  </div>
</section>
<!-- banner section -->
<section class="our-services">
  <div class="container pnone">
    <h3 class="text-center">Our Services</h3>
   <?php
		 if( have_rows('services') ):
		 while ( have_rows('services') ) : the_row(); ?>
      <a href="<?php the_sub_field('link')?>"><div class="services"> <img src="<?php the_sub_field('image')?>" alt="" class="wow animated zoomIn">
        <h4>
          <?php the_sub_field('title')?>
        </h4>
        <p>
          <?php the_sub_field('content')?>
        </p>
      </div></a>
      <?php endwhile; endif; ?>
   
  </div>
</section>
<section class="double-division">
  <div class="container-fluid">
    <div class="col-md-6 col-sm-6 management">
    <div class="medical-audit">
      <h3><?php the_field('title')?></h3>
        <p><?php the_field('content')?></p> 
         <ul>
        <?php
		 if( have_rows('list-row') ):
		 while ( have_rows('list-row') ) : the_row(); ?>
          <li><?php the_sub_field('list')?></li>
          <?php endwhile; endif; ?>
        </ul>
        
        
      </div>
    </div>
    <div class="col-md-6 col-sm-6 testimonial">
     <h4>Testimonials</h4>
    <div class="testibox">
   <div class="testimonial-content slider">
    
        <?php
        if( have_rows('testimonials') ):
        while ( have_rows('testimonials') ) : the_row(); ?>
        <div class="slide">
          <?php the_sub_field('content');?>
           <div class="image"> <img src="<?php the_sub_field('image')?>" class="wow animated zoomIn"/></div>
           <div class="place"> <h5><?php the_sub_field('name')?></h5><?php the_sub_field('place')?></div>
        </div>
       <?php endwhile; endif; ?>
      </div>
      </div>
      <div>
      </div>
    </div>
  </div>
</section>
<section class="client-logo">
  <div class="container">
    <h3 class="text-center">
      <?php the_field('client-title')?>
    </h3>
    <?php
		 if( have_rows('client-logo') ):
		 while ( have_rows('client-logo') ) : the_row(); ?>
    <div class="logos">
      <div class="logo-in"> <img src="<?php the_sub_field('logo')?>" alt="" class="wow animated zoomIn"/> </div>
    </div>
    <?php endwhile; endif; ?>
  </div>
</section>
<section class="career-openings">
  <div class="container">
    <div class="openings">
      <div class="row">
        <div class="col-md-7 col-sm-7">
          <h4><?php the_field('career-title')?></h4>
          <p><?php the_field('career-content')?></p>
        </div>
        <div class="col-md-5 col-sm-5">
          <ul>
          <?php
		 if( have_rows('career-list') ):
		 while ( have_rows('career-list') ) : the_row(); ?>
          <li><?php the_sub_field('list')?></li>
          <?php endwhile; endif; ?>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>
<script src="<?php bloginfo('template_url'); ?>/js/jquery-1.11.1.min.js"></script> 
<script>
$(document).ready(function(){
    $('.testimonial-content').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 3500,
        arrows: true,
        dots: true,
        pauseOnHover: false,
        responsive: [{
            breakpoint: 768,
            settings: {
                slidesToShow: 1
            }
        }, {
            breakpoint: 520,
            settings: {
                slidesToShow:1
            }
        }]
    });
});
</script>
<?php
get_footer();?>
