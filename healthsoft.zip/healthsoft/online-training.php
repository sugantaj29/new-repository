<?php
/**
 * Template Name: Web based Online Training
 */

get_header(); ?>

<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>

<section class="inner-banner" style="background-image:url(<?php echo $featureimg; ?>); ">
  <div class="container">
    <div class="banner-caption">
      <h2>Services</h2>
      <p><?php the_title();?></p>
    </div>
  </div>
</section>

<section class="online-training">
 <div class="container">
   <div class="col-xs-12 pnone">
     <div class="content">
     <?php the_content();?>
     </div>
   </div>
   <div class="col-xs-12 pnone">
  <div class="content_section">
    <div class="content_left">
        <?php the_field('content_left')?>
    </div>
    <div class="right_content">
     <div class="blue_box">
      <h2 class="wow animated fadeIn"><?php the_field('we_have_title')?></h2>
      <ul class="online-list">
        <?php if( have_rows('we_have_list') ):
          while ( have_rows('we_have_list') ) : the_row(); ?>
          <li><?php the_sub_field('have_list_li')?></li>
        <?php endwhile; endif; ?>
      </ul>
     </div>
    </div>
  </div>
 </div>
 </div>
 </section> 

<?php endwhile; // end of the loop. ?>


<?php get_footer(); ?>

