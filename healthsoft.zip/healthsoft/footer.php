<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package wp-bootstrap-starter
 */

?>
</div>
<!-- .row-->
</div>
<!-- .container-fluid -->
</div>
<!-- #content -->

<footer id="site_footer" class="site_footer  footer_bottom">
  <div class="container">
    <div class="row">
      <div class="col-xs-12">
        <div class="footer-logo"> <img src="<?php bloginfo('template_url'); ?>/images/logo.png" class="wow zoomIn animated" alt=""></div>
      </div>
      <div class="col-xs-12">
        <div class="col-md-2 col-sm-4 col-xs-4 address-widget">
          <p> Healthsoft Middle East <br/>
            Po Box: 25134, UAE <br/>
            <a href="callto:971543238020"><img src="<?php bloginfo('template_url'); ?>/images/phone.png"  /> +971 543 238020</a> <br/>
            <a href="mailto:info@healthsoft.ae"><img src="<?php bloginfo('template_url'); ?>/images/mail.png" /> info@healthsoft.ae </a></p>
        </div>
        <div class="col-md-2 col-sm-4 col-xs-4 footer-menu pnone">
          <?php wp_nav_menu( array('menu' => 'footer menu1') ); ?>
        </div>
        <div class="col-md-4 col-sm-4 col-xs-4 footer-menu pnone">
          <?php wp_nav_menu( array('menu' => 'footer menu2') ); ?>
        </div>
        <div class="col-md-4 col-sm-12 social-footer pnone">
          <h4>Stay Connected:</h4>
          <ul>
            <li class="facabook"><a href="https://www.facebook.com/healthsoftuae" target="_blank"><i class="fa fa-facebook wow zoomIn animated" aria-hidden="true"></i>Facebook</a></li>
            <li class="linkedin"><a href="https://www.linkedin.com/company/healthsoft-middle-east/" target="_blank"><i class="fa fa-linkedin wow zoomIn animated" aria-hidden="true"></i>LinkedIn</a></li>
            <li class="twitter"><a href="https://twitter.com/healthsoft_uae" target="_blank"><i class="fa fa-twitter wow zoomIn animated" aria-hidden="true"></i>Twitter</a></li>
          </ul>
        </div>
       </div>
       </div>
       
  </div>
  <div class="cs-copyright-area">
   <div class="container">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <ul><li><a href="privacy-policy/">Privacy Statements </a></li>|<li> <a href="sitemap/">Sitemap </a></li>|<li> <a href="terms-of-use/">Terms of Use </a></li></ul> 
                </div>
                <div class="col-md-6 col-sm-6 copy-right">
                <span>© <script>document.write(new Date().getFullYear())</script> Healthsoft Middle East. All rights reserved.</span>
                </div>
              </div>
            </div>
   </div>
</footer>
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/css/flexslider.css">
<script src="<?php bloginfo('template_url'); ?>/js/wow.min.js" type="text/javascript"></script>
<script src="<?php bloginfo('template_url'); ?>/js/flexslider.min.js"></script>
<script src="<?php bloginfo('template_url'); ?>/js/slick.js"></script>
<script type="text/javascript">
// Can also be used with $(document).ready()
jQuery('.flexslider').flexslider({
  pauseOnAction: true, // default setting
  after: function(slider) {
  /* auto-restart player if paused after action */
  if (!slider.playing) {
    slider.play();
  }
 }
});
</script>
<script>
  new WOW().init();
</script>
<script type="text/javascript">
    jQuery(document).ready(function(){
    jQuery('#nav-icon2').click(function(){
        jQuery(this).toggleClass('open');
		
    });
	
});

</script>
<?php wp_footer(); ?>
</body></html>