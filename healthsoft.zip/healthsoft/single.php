<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package wp-bootstrap-starter
 */

get_header(); ?>

<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle">Blog</h2>
			</div>
		</div>
	</div>
</section>

<!-- /Section: Page Header -->

<!-- Main -->
<main class="main-container">
    <div class="container">
        <div class="row">
            <!-- Blog Content -->
            <div class="col-md-8 col-sm-7">
                <!-- Posts List -->
                <div class="posts-list">

					<?php
					while ( have_posts() ) : the_post();

						get_template_part( 'template-parts/content', get_post_format() );

						// If comments are open or we have at least one comment, load up the comment template.
						if ( comments_open() || get_comments_number() ) :
							comments_template();
						endif;

					endwhile; // End of the loop.
					?>

				</div>
                <!-- /Posts List -->

            </div>
            <!-- /Blog Content -->

            <!-- Blog Sidebar -->
            <div class="col-md-4 col-sm-5">
<div class="recent-post">
<h2>Recent Posts</h2>
<ul> 
	                	<?php
							// Build our basic custom query arguments
							$custom_query_args = array( 
								'posts_per_page' => 3, // Number of related posts to display
								//'post__not_in' => array($post->ID),  Ensure that the current post is not displayed
								'orderby' => 'rand', // Randomize the results
							);
							// Initiate the custom query
							$custom_query = new WP_Query( $custom_query_args );

							// Run the loop and output data for the results
							if ( $custom_query->have_posts() ) : ?>

								<?php while ( $custom_query->have_posts() ) : $custom_query->the_post(); ?>
									 <li>
								        <a href="<?php echo get_permalink() ?>">
                                       
									        <div class="recent-image">
								        		<?php the_post_thumbnail( array( 100, 100 ) );?>
									        </div>
									    </a>
									    <a href="<?php echo get_permalink() ?>"><div class="recent-content"><?php echo the_title();?></div></a>
								    	
								    </li>
								<?php endwhile; ?>
							<?php else : ?>
									<p>Sorry, no related articles to display.</p>
							<?php endif;
							// Reset postdata
							wp_reset_postdata();
							?>
					</ul>
</div>
</div>
            <!-- /Blog Sidebar -->

        </div>
    </div>
</main>
<!-- /Main -->

<?php
get_footer();
