<?php
/**
 * Template Name: Healthcare CDI
 */

get_header(); ?>

<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>

<section class="inner-banner" style="background-image:url(<?php echo $featureimg; ?>); ">
  <div class="container">
    <div class="banner-caption">
      <h2>Services</h2>
      <?php the_content();?>
    </div>
  </div>
</section>

<section class="cdi">
 <div class="container">
   <div class="col-md-5 col-sm-12 col-xs-12 pnone">
   <h3><?php the_field('cdi-title')?></h3>
     <ul class="cdi-list" >
    <?php
		 if( have_rows('cdi-list') ):
		 while ( have_rows('cdi-list') ) : the_row(); ?>
          <li><?php the_sub_field('list')?></li>
          <?php endwhile; endif; ?>
     </ul>
   </div>
   <div class="col-md-7 col-sm-12 col-xs-12 box-set pnone">
   <div class="impact wow animated slideInUp" data-delay="0.5">
   <h4><?php the_field('impact')?></h4>
   </div>
   <div class="increased wow animated zoomIn" data-delay="1">
   <h4><?php the_field('inc-title')?></h4>
   <ul>
    <?php
		 if( have_rows('increased') ):
		 while ( have_rows('increased') ) : the_row(); ?>
          <li><?php the_sub_field('list')?></li>
          <?php endwhile; endif; ?>
     </ul>
   </div>
   <div class="decreased wow animated zoomIn" data-delay="1.5">
   <h4><?php the_field('dec-title')?></h4>
   <ul>
    <?php
		 if( have_rows('decreased') ):
		 while ( have_rows('decreased') ) : the_row(); ?>
          <li><?php the_sub_field('list')?></li>
          <?php endwhile; endif; ?>
     </ul>
   </div>
   </div>
  </div>
 </section>

 



 



<?php endwhile; // end of the loop. ?>


<?php get_footer(); ?>
<style>


@media screen and (max-width: 767px){
  
}

</style>
