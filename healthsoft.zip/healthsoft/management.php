<?php
/**
 * Template Name: Denial Management
 */

get_header(); ?>

<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>

<section class="inner-banner" style="background-image:url(<?php echo $featureimg; ?>); ">
  <div class="container">
    <div class="banner-caption">
      <h2>Services</h2>
     <p> <?php the_title();?></p>
    </div>
  </div>
</section>
<section class="types list_set">
 <div class="container">
 <div class="row">
   <div class="col-md-12 col-sm-12 col-xs-12">
   <h3 class="wow animated zoomIn"><?php the_field('types-title')?></h3>
   <?php
		 if( have_rows('box-row-types') ):
		 while ( have_rows('box-row-types') ) : the_row(); ?>
  <div class="box-list">
   <div class="col-md-4 col-sm-4 col-xs-12">
   
   <h4><?php the_sub_field('box-title')?></h4>
     <ul>
    <?php
		 if( have_rows('list-set') ):
		 while ( have_rows('list-set') ) : the_row(); ?>
          <li><?php the_sub_field('list')?></li>
          <?php endwhile; endif; ?>
     </ul>
     </div>
     </div>
     <?php endwhile; endif; ?>
   </div>
   </div>
  </div>
 </section>
<section class="approach list_set">
 <div class="container">
 <div class="row">
   <div class="col-md-12 col-sm-12 col-xs-12">
   <h3 class="wow animated zoomIn"><?php the_field('approach-title')?></h3>
   <?php
		 if( have_rows('box-row') ):
		 while ( have_rows('box-row') ) : the_row(); ?>
  <div class="box-list">
   <div class="col-md-4 col-sm-4 col-xs-12">
   
   <h4><?php the_sub_field('box-title')?></h4>
     <ul>
    <?php
		 if( have_rows('list-set') ):
		 while ( have_rows('list-set') ) : the_row(); ?>
          <li><?php the_sub_field('list')?></li>
          <?php endwhile; endif; ?>
     </ul>
     </div>
     </div>
     <?php endwhile; endif; ?>
   </div>
   </div>
  </div>
 </section>
<section class="denial-management list_set">
 <div class="container">
 <div class="row">
   <div class="col-md-12 col-sm-12 col-xs-12">
   <h3 class="wow animated zoomIn"><?php the_field('denial-title')?></h3>
     <ul>
    <?php
		 if( have_rows('denial-list') ):
		 while ( have_rows('denial-list') ) : the_row(); ?>
          <li><?php the_sub_field('list')?></li>
          <?php endwhile; endif; ?>
     </ul>
   </div>
   </div>
  </div>
 </section>
















 



<?php endwhile; // end of the loop. ?>


<?php get_footer(); ?>

