<?php
/**
 * Template Name: Services
 */

get_header(); ?>

<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>

<section class="inner-banner" style="background-image:url(<?php echo $featureimg; ?>); ">
  <div class="container">
    <div class="banner-caption">
      <h2>Services</h2>
      <p><?php the_title();?></p>
    </div>
  </div>
</section>

<section class="cycle_management">
 <div class="container">
   <div class="col-xs-12">
     <?php the_content();?>
   </div>
   <div class="col_section">
      <?php
		 if( have_rows('cycle_sec') ):
     while ( have_rows('cycle_sec') ) : the_row(); ?>
      <div class="col-md-6 col-sm-6 col-xs-12 pad-none">
        <div class=""> <img src="<?php the_sub_field('image')?>" alt="" class="img-responsive">
          <h4><?php the_sub_field('title')?></h4>
          <p><?php the_sub_field('content')?></p>
        </div>
      </div>
      <?php endwhile; endif; ?>
    </div>
 </div>
 </section>

 <section class="medical_coding">
 <div class="container">
   <div class="col-xs-12">
     <h2><?php the_field('medical_title')?></h2>
     <p class="text-center"><?php the_field('medical_desc')?></p>
   </div>
   <div class="col_section">
      <?php
		 if( have_rows('medical_sec') ):
     while ( have_rows('medical_sec') ) : the_row(); ?>
      <div class="col-md-4 col-sm-4 col-xs-12 pad-none">
        <div class="img_sec"> <img src="<?php the_sub_field('image')?>" alt="" class="img-responsive"></div>
          <h4><?php the_sub_field('title')?></h4>
          <p><?php the_sub_field('content')?></p>
        </div>
      <?php endwhile; endif; ?>
    </div>
 </div>
</section>
<section class="rcm_consulting">
 <div class="container">
   <div class="col-xs-12">
     <h2><?php the_field('rcm_title')?></h2>
     <p class="text-center"><?php the_field('rcm_desc')?></p>
   </div>
   <div class="col_section">
      <?php
		 if( have_rows('consulting_sec') ):
     while ( have_rows('consulting_sec') ) : the_row(); ?>
      <div class="col-md-6 col-sm-6 col-xs-12 pad-none">
        <div class=""> <img src="<?php the_sub_field('image')?>" alt="" class="img-responsive">
          <h4><?php the_sub_field('title')?></h4>
          <p><?php the_sub_field('content')?></p>
        </div>
      </div>
      <?php endwhile; endif; ?>
    </div>
 </div>
 </section>


 



<?php endwhile; // end of the loop. ?>


<?php get_footer(); ?>
<!--<style>
.inner-banner{position: relative; z-index: 9; clear: both; margin-top: -80px;background-size:cover;background-repeat:no-repeat;background-position:top;width:100%;min-height:383px;display: table;}
.banner-caption{   height: 383px; display: table-cell;  align-items: center;  color: #fff; vertical-align:middle;padding-top: 50px;}
.banner-caption h2{font-size:15px;color: #fff;margin: 30px 0 0px;font-family: 'Ubuntu-Light';}
.banner-caption p{font-size:30px;font-family: 'Ubuntu-Bold'; }
.img_sec{position:relative;height:50px;bottom:0}
.img_sec img {  position: absolute;  bottom: 0;}
.cycle_management{padding:70px 0 80px 0;}
.cycle_management h2{color:#07154a; font-size:22px;font-family: 'Ubuntu-Bold';text-transform:uppercase; text-align:center}
.cycle_management p{font-size:16px; line-height:26px;text-align:center;font-family: 'Myriad-Pro';color: #333;width:95%;margin-left:auto;margin-right:auto}
.cycle_management  .col_section{padding-top:40px;max-width:920px;margin:0 auto;text-align:left; clear: both;}
.cycle_management  .col_section h4{color:#07154a; font-size:18px;font-family: 'Ubuntu-Bold';margin: 14px 0 22px 0;letter-spacing: -0.5px;}
.cycle_management  .col_section p{font-size:15px;text-align:left;font-family: 'Myriad-Pro';color:#666666;margin-left:0;margin-right:0;min-height:120px;line-height: 23px;}
.medical_coding{padding:90px 0 80px 0;color:#fff; background:url(<?php echo get_template_directory_uri(); ?>/images/medical_coding.jpg) no-repeat center top / cover; width:100%;min-height:645px;float:left}
.medical_coding h2{font-size:22px;font-family: 'Ubuntu-Bold';text-transform:uppercase; text-align:center;color: #fff;}
.medical_coding p{font-size:18px; line-height:26px;text-align:center;font-family: 'Myriad-Pro';color: #fff;width:95%;margin-left:auto;margin-right:auto}
.medical_coding  .col_section{padding-top:40px;max-width:1080px;margin:0 auto;text-align:left; clear: both;}
.medical_coding  .col_section h4{font-size:18px;font-family: 'Ubuntu-Bold';margin: 22px 0 22px 0;letter-spacing: -0.5px;color: #fff;}
.medical_coding  .col_section p{font-size:15px;text-align:left;font-family: 'Myriad-Pro';margin-left:0;margin-right:0;min-height:120px;line-height: 23px;}
.rcm_consulting{padding:90px 0 80px 0;clear:both}
.rcm_consulting h2{color:#07154a; font-size:22px;font-family: 'Ubuntu-Bold';text-transform:uppercase; text-align:center}
.rcm_consulting p{font-size:16px; line-height:26px;text-align:center;font-family: 'Myriad-Pro';color: #333;margin-left:auto;margin-right:auto}
.rcm_consulting  .col_section{padding-top:20px;max-width:920px;margin:0 auto;text-align:left; clear: both;}
.rcm_consulting  .col_section h4{color:#07154a; font-size:18px;font-family: 'Ubuntu-Bold';margin: 24px 0 22px 0;letter-spacing: -0.5px;}
.rcm_consulting  .col_section p{font-size:15px;text-align:left;font-family: 'Myriad-Pro';color:#666666;margin-left:0;margin-right:0;line-height: 23px;}
.rcm_consulting  .col_section .col-sm-6:first-child p{padding-right: 43px;}
@media screen and (max-width: 767px){
  .inner-banner{min-height:320px;}
  .banner-caption{   height: 320px;}
  .cycle_management .col_section,.cycle_management .col_section { padding-top: 0px;}
  .cycle_management  .col_section p, .medical_coding  .col_section p, .rcm_consulting  .col_section p{min-height:auto; text-align:center; margin-bottom:35px}
  .cycle_management  .col_section h4,.medical_coding  .col_section h4, .rcm_consulting  .col_section h4{ text-align:center;}
  .cycle_management  .col_section img, .medical_coding  .col_section img, .rcm_consulting  .col_section img{  text-align: center;    display: block;    margin: 0 auto;}
    .medical_coding  .col_section p{min-height:auto;}
  .img_sec img { position:relative;}
  .img_sec {height: auto;}
}
@media screen and (max-width: 514px){
.banner-caption p { font-size: 22px;}
.medical_coding { padding: 90px 0 60px 0}
.cycle_management { padding: 70px 0 60px 0;}
.rcm_consulting { padding: 70px 0 40px 0;}
}
</style>-->
