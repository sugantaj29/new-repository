<?php
/**
 * Template Name: About Us
 */

get_header(); ?>

<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>

<section class="inner-banner" style="background-image:url(<?php echo $featureimg; ?>); ">
  <div class="container">
    <div class="banner-caption">
      <p><?php the_title();?></p>
    </div>
  </div>
</section>

<section class="about_content">
 <div class="container">
   <div class="col-xs-12">
     <?php the_content();?>
   </div>
  </div>
 </section>

<section class="customer_satisfy">
 <div class="container">
  <div class="row">
    <div class="col-xs-12">
        <h2><?php the_field('customer_title')?></h2>
        <div class="bg">
          <div class="content_col">
            <h3><?php the_field('core_title')?></h3>
              <?php if( have_rows('core_values') ):
              while ( have_rows('core_values') ) : the_row(); ?>
                <div class="col-md-6 col-sm-6 col-xs-12 pad-none">
                  <div class="img_sec wow animated zoomIn"> <img src="<?php the_sub_field('value_icon')?>" alt="" class="img-responsive">   </div>
                    <h4><?php the_sub_field('value_title')?></h4>
                    <p><?php the_sub_field('value_content')?></p>
                </div>
              <?php endwhile; endif; ?>
          </div>
          <div class="box_col">
            <h3><?php the_field('vision_title')?></h3>
            <p><?php the_field('vision_desc')?></p>
            <hr>
            <h3><?php the_field('mission_title')?></h3>
            <p><?php the_field('mission_desc')?></p>
          </div>
      </div>
      </div>
    </div>
 </div>
</section>

 



<?php endwhile; // end of the loop. ?>


<?php get_footer(); ?>
<style>
.inner-banner{position: relative; z-index: 9; clear: both; margin-top: -80px;background-size:cover;background-repeat:no-repeat;background-position:top;width:100%;min-height:383px;display: table;}
.banner-caption{   height: 383px; display: table-cell;  align-items: center;  color: #fff; vertical-align:middle;padding-top: 50px;}
.banner-caption h2{font-size:15px;color: #fff;margin: 30px 0 0px;font-family: 'Ubuntu-Light';}
.banner-caption p{font-size:30px;font-family: 'Ubuntu-Bold'; }


@media screen and (max-width: 992px){

}

@media screen and (max-width: 767px){
  .inner-banner{min-height:320px;}
  .banner-caption{   height: 320px;}
  
}
@media screen and (max-width: 514px){
.banner-caption p { font-size: 22px;}
.about_content h2 { font-size: 18px;}

}
</style>
