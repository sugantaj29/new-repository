<?php
/**
* Template Name: Blog
 */

get_header(); ?>
<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>
<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle">Blog</h2>
			</div>
		</div>
	</div>
	</section>
<?php endwhile; // end of the loop. ?>	
<section class="blog-content">
<div class="container">
<div class="row">
<?php $counter = 3;
       $recentPosts = new WP_Query();
       $recentPosts->query('showposts=3');
?>
<article>
<div class="col-md-8 col-sm-7">
<?php while ($recentPosts->have_posts()) : $recentPosts->the_post(); ?>
<div class="post-content">
<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
<div class="postedby"><?php the_time('M d, Y'); ?>&nbsp; |&nbsp; Author :&nbsp; <a href="#"><?php echo get_author_name(); ?></a>
		    <?php $comment_count = get_comment_count($post->ID); ?>
               
<?php if ($comment_count['approved'] > 0) : ?>&nbsp;|&nbsp;<?php comments_popup_link('','0 Comment','% Comments'); ?><?php endif; ?></div>
	<div class="post-thumbnail">
	<p>	<?php the_post_thumbnail(); ?></p>
	</div>
<p><?php echo wp_trim_words( get_the_content(), 80 ); ?> <a href="<?php the_permalink(); ?>">Read more</a></p>
</div>
<?php endwhile; ?>
</div>
</article>

<div class="col-md-4 col-sm-5">
<div class="recent-post">
<h2>Recent Posts</h2>
<ul> 
	                	<?php
							// Build our basic custom query arguments
							$custom_query_args = array( 
								'posts_per_page' => 3, // Number of related posts to display
								//'post__not_in' => array($post->ID),  Ensure that the current post is not displayed
								'orderby' => 'rand', // Randomize the results
							);
							// Initiate the custom query
							$custom_query = new WP_Query( $custom_query_args );

							// Run the loop and output data for the results
							if ( $custom_query->have_posts() ) : ?>

								<?php while ( $custom_query->have_posts() ) : $custom_query->the_post(); ?>
									 <li>
								        <a href="<?php echo get_permalink() ?>">
                                       
									        <div class="recent-image">
								        		<?php the_post_thumbnail( array( 100, 100 ) );?>
									        </div>
									    </a>
									    <a href="<?php echo get_permalink() ?>"><div class="recent-content"><?php echo the_title();?></div></a>
								    	
								    </li>
								<?php endwhile; ?>
							<?php else : ?>
									<p>Sorry, no related articles to display.</p>
							<?php endif;
							// Reset postdata
							wp_reset_postdata();
							?>
					</ul>
</div>
</div>
</div>
</div>
</section>
 
<?php
get_footer();