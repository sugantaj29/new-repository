<?php
/**
 * Template Name: Artificial Intelligence
 */

get_header(); ?>

<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>

<section class="inner-banner" style="background-image:url(<?php echo $featureimg; ?>); ">
  <div class="container">
    <div class="banner-caption">
      <h2>Services</h2>
      <p><?php the_title();?></p>
    </div>
  </div>
</section>

<section class="artificial_sec">
 <div class="container">
   <div class="col-xs-12 pnone">
     <?php the_content();?>
   </div>
   <div class="col-xs-12 pnone">
  <div class="why_you_need">
    <div class="content_col">
      <h3><?php the_field('why_title')?></h3>
          <?php
        if( have_rows('why_ai_sec') ):
        while ( have_rows('why_ai_sec') ) : the_row(); ?>
              <h4><?php the_sub_field('ai_title')?></h4>
              <?php the_sub_field('ai_content')?>
          <?php endwhile; endif; ?>
    </div>
    <div class="box_col">
     <div class="blue_box">
      <h2 class="wow animated fadeIn"><?php the_field('how_title')?></h2>
      <ul class="cdi-list">
        <?php if( have_rows('how_list') ):
          while ( have_rows('how_list') ) : the_row(); ?>
          <li><?php the_sub_field('how_list_li')?></li>
        <?php endwhile; endif; ?>
      </ul>
     </div>
    </div>
  </div>
 </div>
 </div>
 </section> 

<?php endwhile; // end of the loop. ?>


<?php get_footer(); ?>

