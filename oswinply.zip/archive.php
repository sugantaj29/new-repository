<?php

/**

 * The template for displaying Archive pages.

 *

 * Learn more: http://codex.wordpress.org/Template_Hierarchy

 *

 * @package Oswinply

 */



get_header(); ?>

<section class="bannersec">





    <div style="background:#01aa4f;background-size:cover;background-repeat:no-repeat;background-position:center;width:100%;height:310px;">

				

    <div class="caption-content">

    <h2 class="text-center">

						<?php

							if ( is_category() ) :

								single_cat_title();



							elseif ( is_tag() ) :

								single_tag_title();



							elseif ( is_author() ) :

								printf( __( 'Author: %s', 'Oswinply' ), '<span class="vcard">' . get_the_author() . '</span>' );



							elseif ( is_day() ) :

								printf( __( 'Day: %s', 'Oswinply' ), '<span>' . get_the_date() . '</span>' );



							elseif ( is_month() ) :

								printf( __( 'Month: %s', 'Oswinply' ), '<span>' . get_the_date( _x( 'F Y', 'monthly archives date format', 'Oswinply' ) ) . '</span>' );



							elseif ( is_year() ) :

								printf( __( 'Year: %s', 'Oswinply' ), '<span>' . get_the_date( _x( 'Y', 'yearly archives date format', 'Oswinply' ) ) . '</span>' );



							elseif ( is_tax( 'post_format', 'post-format-aside' ) ) :

								_e( 'Asides', 'Oswinply' );



							elseif ( is_tax( 'post_format', 'post-format-gallery' ) ) :

								_e( 'Galleries', 'Oswinply');



							elseif ( is_tax( 'post_format', 'post-format-image' ) ) :

								_e( 'Images', 'Oswinply');



							elseif ( is_tax( 'post_format', 'post-format-video' ) ) :

								_e( 'Videos', 'Oswinply' );



							elseif ( is_tax( 'post_format', 'post-format-quote' ) ) :

								_e( 'Quotes', 'Oswinply' );



							elseif ( is_tax( 'post_format', 'post-format-link' ) ) :

								_e( 'Links', 'Oswinply' );



							elseif ( is_tax( 'post_format', 'post-format-status' ) ) :

								_e( 'Statuses', 'Oswinply' );



							elseif ( is_tax( 'post_format', 'post-format-audio' ) ) :

								_e( 'Audios', 'Oswinply' );



							elseif ( is_tax( 'post_format', 'post-format-chat' ) ) :

								_e( 'Chats', 'Oswinply' );



							else :

								_e( 'Archives', 'Oswinply' );



							endif;

						?>

					</h2>

                    

       </div>

       </div>

     

       </section>             

					<div class="blog-section">

<div class="container">

      <?php $counter = 3;

       $recentPosts = new WP_Query();

       $recentPosts->query('showposts=3');

?>



<div class="col-md-8 col-sm-8 col-xs-12">

<?php while ($recentPosts->have_posts()) : $recentPosts->the_post(); ?>

<div class="col-md-6 col-xs-12 blog-post wow fadeIn">

<div class="post-content">

<div class="post-thumbnail">

	<p>	<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a></p>

	</div>







	

    <div class="content">

    <h2><a href="<?php the_permalink(); ?>"><?php $category_detail=get_the_category($post->ID);//$post->ID

                          foreach($category_detail as $cd){

                          echo $cd->cat_name;

                          }?>  </a> </h2>

<p><a href="<?php the_permalink(); ?>"><?php echo wp_trim_words( get_the_content(), 10 ); ?></a></p>

</div>

</div>

</div>

<?php endwhile; ?>

</div>



          

      

          <div class="col-md-4 col-sm-4 col-xs-12">

            <div class="sidebar-blog">



              <div class="subscribe-box">

                <div class="wrapper">

                  <h2>Get blog posts delivered to your email</h2>

                  <?php echo do_shortcode('[contact-form-7 id="457" title="blog subscribe"]'); ?>

                  <!-- <input type="text" name="Email" placeholder="Enter Your Email">

                  <a href="#" class="subscribe-button">SUBMIT</a> -->

                </div>

              </div> <!-- subscribe box -->



              <div class="recent-box">

	                <h2>Recent Blogs</h2>

	                <ul> 

	                	<?php

							// Build our basic custom query arguments

							$custom_query_args = array( 

								'posts_per_page' => 3, // Number of related posts to display

								//'post__not_in' => array($post->ID),  Ensure that the current post is not displayed

								'orderby' => 'rand', // Randomize the results

							);

							// Initiate the custom query

							$custom_query = new WP_Query( $custom_query_args );



							// Run the loop and output data for the results

							if ( $custom_query->have_posts() ) : ?>



								<?php while ( $custom_query->have_posts() ) : $custom_query->the_post(); ?>

									 <li>

								        <a href="<?php echo get_permalink() ?>">

                                       

									        <div class="recent-image">

								        		<?php the_post_thumbnail( array( 100, 100 ) );?>

									        </div>

									    </a>

									    <a href="<?php echo get_permalink() ?>"><div class="recent-content"><?php echo the_title();?></div></a>

								    	

								    </li>

								<?php endwhile; ?>

							<?php else : ?>

									<p>Sorry, no related articles to display.</p>

							<?php endif;

							// Reset postdata

							wp_reset_postdata();

							?>

					</ul>

	              </div>



            </div>

          </div>

        </div>

      </div>



<?php //get_sidebar(); ?>

<?php get_footer(); ?>

