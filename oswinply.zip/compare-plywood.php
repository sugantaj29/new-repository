<?php
/**
 * Template Name: Compare Plywoods
 */

get_header(); ?>
 <?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>
<section class="bannersec">
    <div style="background-image:url(<?php echo $featureimg; ?>);background-size:cover;background-repeat:no-repeat;background-position:center;width:100%;height:310px;">
				
    <div class="caption-content">
    <h2 class="text-center"><?php echo the_title();?></h2>
    </div>
                
    </div>          
</section>

<div class="page-crumbs">
<div class="container">
<?php custom_breadcrumbs(); ?>
</div>
</div>



<section class="compare-table">
<div class="container">
<h2><?php the_field('title')?></h2>

<div class="row">

<div class="col-md-5 col-md-offset-1 col-sm-5 col-sm-offset-1 col-xs-6">
<select class="type2">
<option value="Club">Oswin Club</option><option value="Platinum">Oswin Platinum</option><option value="Gold">Oswin Gold</option><option value="Commercial">Oswin Commercial</option>
</select>
</div>
<div class="col-md-5 col-md-offset-1 col-sm-5 col-xs-6">
<select class="type1">
<option value="Club">Oswin Club</option><option value="Platinum">Oswin Platinum</option><option value="Gold">Oswin Gold</option><option value="Commercial">Oswin Commercial</option>
</select>
</div>

</div>
<div class="comparison-table">

<div class="col-md-5 col-md-offset-1 col-sm-5 col-sm-offset-1 col-xs-6">
<div class="compare-box-one">
<!--<div class="row_dim_box1">
<h4>Raw Material</h4>
<p>100% Internationally
Sourced Timber</p>

<h4>Resin</h4>
<p>AR Technology </p>

<h4>Waterproof</h4>
<p>108 hours</p>

<h4>Glue Spread</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/5star.png"></p>

<h4>Glue Bonding</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/5star.png"></p>

<h4>Termite Treatment Process</h4>
<p>Yes</p>

<h4>Price</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/5star.png"></p>


</div>

<div class="row_dim_box2">
<h4>Raw Material</h4>
<p>Internationally sourced
Timber and Selected Indian  
Hardwood</p>

<h4>Resin</h4>
<p>AR Technology </p>

<h4>Waterproof</h4>
<p>108 hours</p>

<h4>Glue Spread</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/5star.png"></p>

<h4>Glue Bonding</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/5star.png"></p>

<h4>Termite Treatment Process</h4>
<p>Yes</p>

<h4>Price</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/half-star.png"></p>




</div>
<div class="row_dim_box3">
<h4>Raw Material</h4>
<p>Selected Indian hardwood
with Internationally
Sourced Timber</p>
<h4>Resin</h4>
<p>AR Technology </p>

<h4>Waterproof</h4>
<p>72 hours</p>

<h4>Glue Spread</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/star1.png"></p>

<h4>Glue Bonding</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/star1.png"></p>

<h4>Termite Treatment Process</h4>
<p>Yes</p>

<h4>Price</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/star1.png"></p>



</div>


<div class="row_dim_box4">

<h4>Raw Material</h4>
<p>Selected Indian 
Hardwood</p>

<h4>Resin</h4>
<p>MUF Technology</p>

<h4>Waterproof</h4>
<p>-</p>

<h4>Glue Spread</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/3star.png"></p>

<h4>Glue Bonding</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/3star.png"></p>

<h4>Termite Treatment Process</h4>
<p>No</p>

<h4>Price</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/3star.png"></p>
</div>-->
<?php echo the_field('compare-box-one');?>

</div>
</div>
<div class="col-md-5 col-md-offset-1 col-sm-5 col-xs-6">
<div class="compare-box">
<!--<div class="row_dim_box11">
<h4>Raw Material</h4>
<p>100% Internationally
Sourced Timber</p>

<h4>Resin</h4>
<p>AR Technology </p>

<h4>Waterproof</h4>
<p>108 hours</p>

<h4>Glue Spread</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/5star.png"></p>

<h4>Glue Bonding</h4>

<p><img src="<?php bloginfo('template_url');?>/inc/images/5star.png"></p>

<h4>Termite Treatment Process</h4>
<p>Yes</p>

<h4>Price</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/5star.png"></p>



</div>

<div class="row_dim_box12">
<h4>Raw Material</h4>
<p>Internationally sourced
Timber and Selected Indian  
Hardwood</p>

<h4>Resin</h4>
<p>AR Technology </p>

<h4>Waterproof</h4>
<p>108 hours</p>

<h4>Glue Spread</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/5star.png"></p>

<h4>Glue Bonding</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/5star.png"></p>

<h4>Termite Treatment Process</h4>
<p>Yes</p>

<h4>Price</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/half-star.png"></p>




</div>
<div class="row_dim_box13">
<h4>Raw Material</h4>
<p>Selected Indian hardwood
with Internationally
Sourced Timber</p>
<h4>Resin</h4>
<p>AR Technology </p>

<h4>Waterproof</h4>
<p>72 hours</p>

<h4>Glue Spread</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/star1.png"></p>

<h4>Glue Bonding</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/star1.png"></p>

<h4>Termite Treatment Process</h4>
<p>Yes</p>

<h4>Price</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/star1.png"></p>


</div>


<div class="row_dim_box14">
<h4>Raw Material</h4>
<p>Selected Indian 
Hardwood</p>

<h4>Resin</h4>
<p>MUF Technology</p>

<h4>Waterproof</h4>
<p>-</p>

<h4>Glue Spread</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/3star.png"></p>

<h4>Glue Bonding</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/3star.png"></p>

<h4>Termite Treatment Process</h4>
<p>No</p>

<h4>Price</h4>
<p><img src="<?php bloginfo('template_url');?>/inc/images/3star.png"></p>

</div>-->
<?php echo the_field('compare-box-two');?>
</div>
</div>

</div>


<div class="specification">
<h3><?php echo the_field('specification-title');?></h3>
</div>
<div class="spec">
<?php echo the_field('specification');?>
<!--<div class="spec-out isi">



<h5><strong>IS:710 BWP
Requirement</strong></h5>
<h4> Density </h4>
<p>.65 - .70</p>

<h4>Moisture Content</h4>
<p>5-15%</p>
<h4>Glue Shear Strength (Dry)</h4>
<p> Average Min 1350 N</p>

<h4>Water Resistance test</h4>
<p>Water Resistance test  More than 1200 N</p>

<h4>Mycological Test </h4>
<p>More than 1150 N</p>

<h4>Boiling Water Test  </h4>
<p>No Delamination even
after boiling for 108 hrs</p>

<h4>Specific Gravity </h4>
<p> 7 -.85</p>

<h4>Screw Holding Strenght </h4>
<p>More than 350 Kgs</p>

<h4> Nail Holding Strength (Normal to Face) </h4>
<p>More than 75Kgs</p>

<h4>Water Absorption </h4>
<p>Less than 4.5%</p>
<h4>Tensile Strength </h4>
<p> Not less than 42N/
mm² (parallel to grain)</p>

<h4>Tolerance </h4>
<p>Length ± 0-6 mm <br/>
Width ± 0-3 mm</p>

<h4>Squareness</h4>
<p>2mm/1 mm or 0.2%</p>

</div>

<div class="spec-out">
<div class="row_dim_box1">
<h5><strong>Oswin Club</strong></h5>
<h4> Density </h4>
<p> Complaint</p>
<h4>Moisture Content</h4>
<p> 8-9%</p>
<h4>Glue Shear Strength (Dry)</h4>
<p>1800 N</p>
<h4>Water Resistance test </h4>
<p>1300 N</p>
<h4>Mycological Test </h4>
<p>1250 N</p>
<h4>Boiling Water Test </h4>
<p>Passed/No Delamination</p>
<h4>Specific Gravity </h4>
<p>Compliant</p>
<h4>Screw Holding Strength</h4>
<p>450 kgs</p>
<h4>Nail Holding Strength (Normal to Face) </h4>
<p>185 kgs</p>
<h4>Water Absorption </h4>
<p>Compliant</p>
<h4>Tensile Strength </h4>
<p>55 N/m²</p>
<h4>Tolerance</h4>
<p>Length – 2 mm <br/>
Width – 2 mm</p>
<h4>Squareness</h4>
<p>0.15%</p>
</div>
<div class="row_dim_box2">
<h5><strong>Oswin Platinum</strong></h5>
<h4> Density </h4>
<p>Compliant</p>
<h4>Moisture Content</h4>
<p> 8-9%</p>
<h4>Glue Shear Strength (Dry)</h4>
<p>1650 N</p>
<h4>Water Resistance test</h4>
<p>1300 N</p>

<h4>Mycological Test</h4>
<p>1250 N</p>

<h4>Boiling Water Test</h4>
<p>Passed/No Delamination</p>
<h4>Specific Gravity</h4>
<p>Compliant</p>
<h4>Screw Holding Strength</h4>
<p> 400 kgs</p>
<h4>Nail Holding Strength (Normal to Face)</h4>
<p>  130 kgs</p>
<h4>Water Absorption</h4>
<p>Compliant</p>
<h4>Tensile Strength</h4>
<p> 45 N/m²</p>
<h4>Tolerance</h4>
<p>Length – 2 mm <br/>
Width – 2 mm</p>
<h4>Squareness</h4>
<p>0.17%</p>
</div>
<div class="row_dim_box3">
<h5><strong>Oswin Gold</strong></h5>
<h4>Density</h4>
<p>Compliant</p>

<h4>Moisture Content</h4>
<p> 8-9%</p>

<h4>Glue Shear Strength (Dry)</h4>
<p>1800 N</p>
<h4>Water Resistance test</h4>
<p>1300 N</p>
<h4>Mycological Test</h4>
<p>1250 N</p>
<h4>Boiling Water Test</h4>
<p>Passed/No Delamination</p>
<h4>Specific Gravity</h4>
<p>Compliant</p>
<h4>Specific Gravity</h4>
<p>450 kgs</p>
<h4>Nail Holding Strength (Normal to Face)</h4>
<p>185 kgs</p>
<h4>Water Absorption </h4>

<p>Compliant</p>
<h4>Water Absorption </h4>

<p>55 N/m²</p>
<h4>Tolerance</h4>
<p>Length – 2 mm <br/>
Width – 2 mm</p>
<h4>Squareness</h4>
<p>0.15%</p>
</div>
<div class="row_dim_box4">
<h5><strong>Oswin Commercial</strong></h5>
<h4>Density</h4>
<p>-</p>
<h4>Glue Shear Strength (Dry)</h4>

<p>7-10%</p>
<h4>Glue Shear Strength (Dry)</h4>
<p>860 N-1120 N</p>
<h4>Water Resistance test</h4>
<p>780 N – 910 N</p>
<h4>Mycological Test</h4>
<p>710 N – 910 N</p>
<h4>Boiling Water Test</h4>
<p>-</p>
<h4>Specific Gravity</h4>
<p>-</p>
<h4>Screw Holding Strength</h4>
<p>-</p>
<h4>Nail Holding Strength (Normal to Face)</h4>
<p>-</p>
<h4>Water Absorption</h4>
<p>-</p>
<h4>Tensile Strength</h4>

<p>-</p>
<h4>Tolerance</h4>
<p>-</p>
<h4>Squareness</h4>
<p>-</p>
</div>
</div>
<div class="spec-out">
<div class="row_dim_box11">
<h5><strong>Oswin Club</strong></h5>
<h4> Density </h4>
<p> Complaint</p>
<h4>Moisture Content</h4>
<p> 8-9%</p>
<h4>Glue Shear Strength (Dry)</h4>
<p>1800 N</p>
<h4>Water Resistance test </h4>
<p>1300 N</p>
<h4>Mycological Test </h4>
<p>1250 N</p>
<h4>Boiling Water Test </h4>
<p>Passed/No Delamination</p>
<h4>Specific Gravity </h4>
<p>Compliant</p>
<h4>Screw Holding Strength</h4>
<p>450 kgs</p>
<h4>Nail Holding Strength (Normal to Face) </h4>
<p>185 kgs</p>
<h4>Water Absorption </h4>
<p>Compliant</p>
<h4>Tensile Strength </h4>
<p>55 N/m²</p>
<h4>Tolerance</h4>
<p>Length – 2 mm <br/>
Width – 2 mm</p>
<h4>Squareness</h4>
<p>0.15%</p>
</div>
<div class="row_dim_box12">
<h5><strong>Oswin Platinum</strong></h5>
<h4> Density </h4>
<p>Compliant</p>
<h4>Moisture Content</h4>
<p> 8-9%</p>
<h4>Glue Shear Strength (Dry)</h4>
<p>1650 N</p>
<h4>Water Resistance test</h4>
<p>1300 N</p>

<h4>Mycological Test</h4>
<p>1250 N</p>

<h4>Boiling Water Test</h4>
<p>Passed/No Delamination</p>
<h4>Specific Gravity</h4>
<p>Compliant</p>
<h4>Screw Holding Strength</h4>
<p> 400 kgs</p>
<h4>Nail Holding Strength (Normal to Face)</h4>
<p>  130 kgs</p>
<h4>Water Absorption</h4>
<p>Compliant</p>
<h4>Tensile Strength</h4>
<p> 45 N/m²</p>
<h4>Tolerance</h4>
<p>Length – 2 mm <br/>
Width – 2 mm</p>
<h4>Squareness</h4>
<p>0.17%</p>
</div>
<div class="row_dim_box13">
<h5><strong>Oswin Gold</strong></h5>
<h4>Density</h4>
<p>Compliant</p>

<h4>Moisture Content</h4>
<p> 8-9%</p>

<h4>Glue Shear Strength (Dry)</h4>
<p>1800 N</p>
<h4>Water Resistance test</h4>
<p>1300 N</p>
<h4>Mycological Test</h4>
<p>1250 N</p>
<h4>Boiling Water Test</h4>
<p>Passed/No Delamination</p>
<h4>Specific Gravity</h4>
<p>Compliant</p>
<h4>Specific Gravity</h4>
<p>450 kgs</p>
<h4>Nail Holding Strength (Normal to Face)</h4>
<p>185 kgs</p>
<h4>Water Absorption </h4>

<p>Compliant</p>
<h4>Water Absorption </h4>

<p>55 N/m²</p>
<h4>Tolerance</h4>
<p>Length – 2 mm <br/>
Width – 2 mm</p>
<h4>Squareness</h4>
<p>0.15%</p>
</div>
<div class="row_dim_box14">
<h5><strong>Oswin Commercial</strong></h5>
<h4>Density</h4>
<p>-</p>
<h4>Glue Shear Strength (Dry)</h4>

<p>7-10%</p>
<h4>Glue Shear Strength (Dry)</h4>
<p>860 N-1120 N</p>
<h4>Water Resistance test</h4>
<p>780 N – 910 N</p>
<h4>Mycological Test</h4>
<p>710 N – 910 N</p>
<h4>Boiling Water Test</h4>
<p>-</p>
<h4>Specific Gravity</h4>
<p>-</p>
<h4>Screw Holding Strength</h4>
<p>-</p>
<h4>Nail Holding Strength (Normal to Face)</h4>
<p>-</p>
<h4>Water Absorption</h4>
<p>-</p>
<h4>Tensile Strength</h4>

<p>-</p>
<h4>Tolerance</h4>
<p>-</p>
<h4>Squareness</h4>
<p>-</p>
</div>
</div>-->
</div>

</div>
</section>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script>
$(function() {
    $('.row_dim_box1').hide(); 
    $('.type2').change(function(){
        if($('.type2').val() == 'Club') {
            $('.row_dim_box1').show(); 
			$('.spec').show(); 
			$('.row_dim_box1').removeClass('none'); 
        } else {
            $('.row_dim_box1').hide(); 
        } 
    });
    $('.row_dim_box2').hide(); 
    $('.type2').change(function(){
        if($('.type2').val() == 'Platinum') {
            $('.row_dim_box2').show();
			$('.spec').show();  
			$('.row_dim_box1').addClass('none'); 
            
		} else {
            $('.row_dim_box2').hide(); 
        } 
    });
    $('.row_dim_box3').hide(); 
    $('.type2').change(function(){
        if($('.type2').val() == 'Gold') {
            $('.row_dim_box3').show(); 
			$('.spec').show(); 
			$('.row_dim_box1').addClass('none'); 
           
		} else {
            $('.row_dim_box3').hide(); 
        } 
    });
    $('.row_dim_box4').hide(); 
    $('.type2').change(function(){
        if($('.type2').val() == 'Commercial') {
            $('.row_dim_box4').show();
			$('.spec').hide(); 
			$('.row_dim_box1').addClass('none');  
         } else {
            $('.row_dim_box4').hide(); 
        } 
    });
	$('.row_dim_box11').hide(); 
    $('.type1').change(function(){
        if($('.type1').val() == 'Club') {
            $('.row_dim_box11').show();
			 $('.spec').show(); 
			$('.row_dim_box11').removeClass('none');  
            
		} else {
            $('.row_dim_box11').hide(); 
        } 
    });
    $('.row_dim_box12').hide(); 
    $('.type1').change(function(){
        if($('.type1').val() == 'Platinum') {
            $('.row_dim_box12').show(); 
			$('.spec').show(); 
			$('.row_dim_box11').addClass('none'); 
            
		} else {
            $('.row_dim_box12').hide(); 
        } 
    });
    $('.row_dim_box13').hide(); 
    $('.type1').change(function(){
        if($('.type1').val() == 'Gold') {
            $('.row_dim_box13').show(); 
			 $('.spec').show(); 
            $('.row_dim_box11').addClass('none');
			
		} else {
            $('.row_dim_box13').hide(); 
        } 
    });
    $('.row_dim_box14').hide(); 
    $('.type1').change(function(){
        if($('.type1').val() == 'Commercial') {
         $('.row_dim_box14').show(); 
		 $('.spec').hide(); 
		$('.row_dim_box11').addClass('none');
		} else {
            $('.row_dim_box14').hide(); 
			
        } 
    });
	
	
	
});
</script>

<?php endwhile; // end of the loop. ?>	
<?php get_footer(); ?>
