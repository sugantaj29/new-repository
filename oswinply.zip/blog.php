<?php

/**

 * Template Name: Blog

 */





get_header(); ?>

 <?php while ( have_posts() ) : the_post();

$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );

$custom=get_post_custom($post->ID);

$page_title = $post->post_name;

?>

<section class="bannersec">





    <div class="blog-banner" style="background:#01aa4f;background-size:cover;background-repeat:no-repeat;background-position:center;width:100%;height:100px;">

				

    <div class="caption-content">

    <h2 class="text-center"><?php echo the_title();?></h2>

    </div>

                

    </div>  

</section>

<div class="page-crumbs">

<div class="container">

<?php custom_breadcrumbs(); ?>

</div>

</div>

<div class="blog-section">

<div class="container">



      <?php $counter = 2;

       $recentPosts = new WP_Query();

       $recentPosts->query('showposts=20');

?>



<div class="col-md-8 col-sm-8 col-xs-12">





<?php while ($recentPosts->have_posts()) : $recentPosts->the_post(); ?>







<div class="col-sm-6 col-xs-12 blog-post wow fadeIn">





<div class="post-content">





<div class="post-thumbnail">

	<p>	<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a></p>

	</div>







	

    <div class="content">

    

    <h2><a href="<?php the_permalink(); ?>"><?php $category_detail=get_the_category($post->ID);//$post->ID

                          foreach($category_detail as $cd){

                          echo $cd->cat_name;

                          }?> </a>  </h2>

<p><a href="<?php the_permalink(); ?>"><?php echo wp_trim_words( get_the_title(), 10 ); ?></a></p>

</div>

</div>

</div>

<?php endwhile; ?>

</div>



   

      

          <div class="col-md-4 col-sm-12 col-xs-12">

            <div class="sidebar-blog">



              <div class="subscribe-box">

                <div class="wrapper">

                  <h2>Get blog posts delivered to your email</h2>

                  <?php echo do_shortcode('[contact-form-7 id="457" title="blog subscribe"]'); ?>

                  <!-- <input type="text" name="Email" placeholder="Enter Your Email">

                  <a href="#" class="subscribe-button">SUBMIT</a> -->

                </div>

              </div> <!-- subscribe box -->



              <!--<div class="browse-box">

                <h2>Browse Blog Topics</h2>

                  <ul>

                      <?php wp_list_categories( array(

                          'orderby' => 'name',

                          'title_li' => ''

                      ) ); ?> 

                  </ul>

              </div>-->

              <div class="recent-box">

	                <h2>Recent Blogs</h2>

	                <ul> 

	                	<?php

							// Build our basic custom query arguments

							$custom_query_args = array( 

								'posts_per_page' => 3, // Number of related posts to display

								//'post__not_in' => array($post->ID),  Ensure that the current post is not displayed

								'orderby' => 'rand', // Randomize the results

							);

							// Initiate the custom query

							$custom_query = new WP_Query( $custom_query_args );



							// Run the loop and output data for the results

							if ( $custom_query->have_posts() ) : ?>



								<?php while ( $custom_query->have_posts() ) : $custom_query->the_post(); ?>

									 <li>

								        <a href="<?php echo get_permalink() ?>">

                                       

									        <div class="recent-image">

								        		<?php the_post_thumbnail( array( 100, 100 ) );?>

									        </div>

									    </a>

									    <a href="<?php echo get_permalink() ?>"><div class="recent-content"><?php echo the_title();?></div></a>

								    	

								    </li>

                                    

                                   

                                    

                                    

                                    

								<?php endwhile; ?>

                              

							<?php else : ?>

									<p>Sorry, no related articles to display.</p>

							<?php endif;

							// Reset postdata

							wp_reset_postdata();

							?>

					</ul>

                    

                   

	              </div>



            </div>

            <div class="blog-iframe">

            <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Foswinply&tabs=timeline&width=280&height=500&small_header=true&adapt_container_width=true&hide_cover=true&show_facepile=false&appId=2014294418863013" width="100%" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

           </div>

          </div>

        </div>

      </div>

      





  

            



<?php endwhile; // end of the loop. ?>	

<style>

._2p3a{width:300px !important;}

</style>  

<?php get_footer(); ?>



 

