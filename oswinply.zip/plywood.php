<?php

/**

 * Template Name: Plywood

 */


header('Location:https://www.oswinply.com/products/plywood/oswin-club/');

get_header(); ?>

 <?php while ( have_posts() ) : the_post();

$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );

$custom=get_post_custom($post->ID);

$page_title = $post->post_name;

?>

	

<section class="bannersec">

    <div style="background-image:url(<?php echo $featureimg; ?>);background-size:cover;background-repeat:no-repeat;background-position:center;width:100%;height:310px;">

				

    <div class="caption-content">

    <h2 class="text-center"><?php echo the_field('title')?></h2>

    <p class="text-center"><?php echo the_field('paragraph')?></p>

    </div>

                

    </div>          

</section>

<div class="page-crumbs">

<div class="container">

<ul class="breadcrumb">

  <li><a href="#">Home</a></li>

  <li><a href="#">Products</a></li>

  <li>Oswin Club</li>

</ul>

</div>

</div>

<section class="oswinply">

<div class="container">

<div class="tabbing">

  <ul class="tabNav">

  <?php

        if( have_rows('tab-title') ):

		 $i=0; 

        while ( have_rows('tab-title') ) : the_row(); ?>

    <li><a href="#tab1<?php echo $i; ?>"><?php echo the_sub_field('title')?>  </a></li>

    <?php $i++; 

   endwhile; endif; ?>

  

  </ul>

  

  <div class="tabContainer">

  <?php

        if( have_rows('tabcontent') ):

		$i=0;  

        while ( have_rows('tabcontent') ) : the_row(); ?>

    <div class="tabContent" id="tab1<?php echo $i; ?>">

   <div class="col-md-8 col-sm-8 col-xs-12">

   <div class="content">

      <h3><?php echo the_sub_field('title')?></h3>

      <p><?php echo the_sub_field('content')?></p>

   </div>

   </div>

   <div class="col-md-4 col-sm-4 col-xs-12">

   <img  src="<?php echo the_sub_field('image')?>" />

   </div>

    </div>

     <?php $i++; 

   endwhile; endif; ?>

  

    

  </div>

</div>

</div>

</section>

<section class="marine-grade-plywoods">

<div class="container">

<div class="col-md-3 col-sm-3 col-xs-12">

<div class="sidebar">

<ul>

 

<li><a href="#" class="active">Oswin Club </a></li>

  

<li><a href="#">Oswin Platinum </a></li>

  

<li><a href="#">Oswin Gold </a></li>

  

<li><a href="#">Oswin Commercial</a></li>

  

<li><a href="#">Film Faced Shuttering Ply </a></li>

  

<li><a href="#">Flexiply </a></li>



 </ul>

 <a href="<?php echo the_field('compare-link')?>" class="compare">Compare PLYWOODS</a>

</div>

</div>

<div class="col-md-5 col-sm-9 col-xs-12">

<div class="marine-grade">

<h2><?php echo the_field('marine-title')?></h2>

<p><?php echo the_field('content')?></p>

<h3><?php echo the_field('tech-title')?></h3>

<?php echo the_field('specification')?>





<!--<ul>

 

<li><span>ISI standard </span><span>IS 710:2010</span></li>

  

<li><span>Raw Material </span><span>Internationally <br/>sourced  timber <br/> and selected internationally<br/> sourced hardwood</span></li>

  

<li><span>Resin </span><span>Super Phenol Formaldehyde</span></li>

  

<li><span>Waterproof under 100’C for <br>(After 72 hours boiling at 100°C)</span><span>108 hours</span></li>

  

<li><span>Glue Spread </span><span>7 - 12 %</span></li>

  

<li><span>Glue Bonding </span><span>108 hours</span></li>

  

<li><span>DIP Technology 	</span><span> Yes</span></li>



<li><span>Termite Treatment Process </span><span> Yes </span></li>



<li><span>Price </span><span> 4 star </span></li>



<li><span>Density gms/cc  </span><span> 0.65 to 0.70 </span></li>



<li><span>Moisture Content  </span><span> 6-9% </span></li>



<li><span>Glue Sheer Strength (Dry State) </span><span>More than 1350N </span></li>



<li><span>More than 1000N </span><span>More than 1000N </span></li>



<li><span>Mycological Test   </span><span>No Delamination<br/> even after boiling <br/>for 108 hrs </span></li>



<li><span>Boiling Water Test   </span><span>Excellent </span></li>



<li><span>Glue Adhesion   </span><span>0.70 to 0.85 </span></li>



<li><span>Specific Gravity   </span><span>More than 250 kgs </span></li>



<li><span>Screw Holding Strength    </span><span>More than 60 kgs </span></li>



<li><span>Nail Holding Strength Normal to face     </span><span>Less than 3.5% </span></li>



<li><span>Water Absorption   </span><span>Yes </span></li>



<li><span>Tensile Strength   </span><span>600 kg/sq.cm. </span></li>



</ul>

<ul>

<?php

if( have_rows('tech-list') ):

while ( have_rows('tech-list') ) : the_row(); ?> 

<li><span><?php echo the_sub_field('one')?></span><span><?php echo the_sub_field('two')?></span></li>

 <?php endwhile; endif; ?>

</ul>



<h3><?php echo the_field('standard-title')?></h3>



<ul>

<?php

if( have_rows('standard') ):

while ( have_rows('standard') ) : the_row(); ?> 

<li><?php echo the_sub_field('list-content')?></li>

 <?php endwhile; endif; ?>

</ul>





<h3><?php echo the_field('thick-title')?></h3>

<ul>

 <?php

if( have_rows('thickness') ):

while ( have_rows('thickness') ) : the_row(); ?>

<li><?php echo the_sub_field('list-content')?></li>

 <?php endwhile; endif; ?>

</ul>

-->

<div class="icons">

 <?php

if( have_rows('icon-one') ):

while ( have_rows('icon-one') ) : the_row(); ?>

<div class="icon-in animated wow zoomIn"><img src="<?php echo the_sub_field('icon')?>" /></div>

 <?php endwhile; endif; ?>



</div>



<div class="icons">

 <?php

if( have_rows('icon-two') ):

while ( have_rows('icon-two') ) : the_row(); ?>

<div class="icon-in animated wow zoomIn"><img src="<?php echo the_sub_field('icon')?>" /></div>

 <?php endwhile; endif; ?>

</div>

</div>

</div>

<div class="col-md-4 col-sm-12 col-xs-12">

<div class="ply-wood-img pull-right">

<div class="sp-loading"><img src="<?php bloginfo('template_url'); ?>/inc/images/sp-loading.gif" alt=""><br>LOADING IMAGES</div>

		<div class="sp-wrap">

         <?php

if( have_rows('plywood-img') ):

while ( have_rows('plywood-img') ) : the_row(); ?>

<a href="<?php echo the_sub_field('small')?>"><img src="<?php echo the_sub_field('big')?>" alt=""></a>

 <?php endwhile; endif; ?>

			

		</div></div>

</div>

</div>

</section>



<?php endwhile; // end of the loop. ?>	

<?php get_footer(); ?>

