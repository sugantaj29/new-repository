<?php

/**

 * Template Name: Sitemap

 */





get_header(); ?>

<?php while ( have_posts() ) : the_post();

$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );

$custom=get_post_custom($post->ID);

$page_title = $post->post_name;

?>



<section class="bannersec">

  <div style="background:#01a951;background-size:cover;background-repeat:no-repeat;background-position:center;width:100%;height:200px;">

    <div class="caption-content">

      <h2 class="text-center"><?php echo the_title();?></h2>

    </div>

  </div>

</section>

<div class="page-crumbs">

  <div class="container">

    <?php custom_breadcrumbs(); ?>

  </div>

</div>

<section class="sitemap">

<div class="container">

<div class="col-md-6 col-sm-6 col-xs-12">



<?php //wp_nav_menu(array('menu'=>'products'));?>

<?php //wp_nav_menu(array('menu'=>'product-set-two'));?>

<?php //wp_nav_menu(array('menu'=>'discover'));?>



<ul>

    <li><a href="https://www.oswinply.com/">Home</a></li>

    <li><a href="https://www.oswinply.com/about-us/">About us</a>

    <li><a href="https://www.oswinply.com/">Products</a>

      <?php wp_nav_menu(array('menu'=>'products'));?>

<?php wp_nav_menu(array('menu'=>'product-set-two'));?>

    </li>

    

    

    <li><a href="https://www.oswinply.com/manufacturing-process/">Manufacturing Process</a></li>

    <li><a href="https://www.oswinply.com/quality/">Quality</a></li>

    <li><a href="https://www.oswinply.com/blog/">Blog</a></li>

    <li><a href="https://www.oswinply.com/contact/">Contact us</a></li>

</ul>



</div>

<div class="col-md-6 col-sm-6  col-xs-12">

    

  

</div>

</div>



</section>

<?php endwhile; // end of the loop. ?>

<?php get_footer(); ?>

