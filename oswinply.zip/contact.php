<?php
/**
 * Template Name: Contact
 */


get_header(); ?>
 <?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>
	
<section class="bannersec">
    <div style="background-image:url(<?php echo $featureimg; ?>);background-size:cover;background-repeat:no-repeat;background-position:center;width:100%;height:310px;">
				
    <div class="caption-content">
     <h2 class="text-center"><?php echo the_title();?></h2>
    </div>
                
    </div>          
</section>
<div class="page-crumbs">
<div class="container">
<?php custom_breadcrumbs(); ?></div>
</div>
<section class="contact">
<div class="container">
<div class="col-md-6 col-sm-6 col-xs-12">
<h2><?php the_title();?></h2>
<?php the_content();?>
<div class="social-icon">
                <ul>
                   <li><a href="https://www.facebook.com/oswinply/" class="fb" target="_blank"><i class="fa fa-facebook"></i></a></li>
                   <li><a href="https://twitter.com/oswinplywood" class="tw" target="_blank"><i class="fa fa-twitter"></i></a></li>
                   <li><a href="https://www.linkedin.com/company/oswinply" class="in" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                   <li><a href="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3886.123431323992!2d80.26690131482329!3d13.091362990777391!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a5265fa45e6d001%3A0xf2801144c0922f57!2sOswin+Wood+Panels+Pvt.Ltd!5e0!3m2!1sen!2sin!4v1544007223302"  class="lt"  target="_blank"><i class="fa fa-map-marker"></i></a></li>
                   </ul>
                  
                   </div>
<div class="phone">
<h3>Telephone</h3>

<ul>
<?php
        if( have_rows('phone') ):
        while ( have_rows('phone') ) : the_row(); ?>
<li><?php the_sub_field('list');?></li>
 <?php endwhile; endif; ?>
</ul>

</div>
<div class="fax">
<h3>Fax</h3>

<ul>
<?php
        if( have_rows('fax') ):
        while ( have_rows('fax') ) : the_row(); ?>
<li><?php the_sub_field('list');?></li>
 <?php endwhile; endif; ?>
</ul>

</div>
<div class="mail">
<h3>Email</h3>
<?php
        if( have_rows('mail') ):
        while ( have_rows('mail') ) : the_row(); ?>
<h4><?php the_sub_field('title');?></h4>
<?php the_sub_field('email');?>
<p><?php the_sub_field('content');?></p>
 <?php endwhile; endif; ?>
</div>
</div>
<div class="col-md-6 col-sm-6 col-xs-12">
<div class="map">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3886.123431323992!2d80.26690131482329!3d13.091362990777391!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a5265fa45e6d001%3A0xf2801144c0922f57!2sOswin+Wood+Panels+Pvt.Ltd!5e0!3m2!1sen!2sin!4v1544007223302" width="100%" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>
<div class="formout">
<h3>Submit an Enquiry</h3>

<?php echo do_shortcode ('[contact-form-7 id="279" title="Contact Form"]')?>




</div>
</div>

</div>
</section>
<section class="testpopup">
<!-- Button trigger modal -->
<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal1">
  Player 1
</button>

<!-- Modal -->
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Modal title 1</h4>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default btn-prev">Prev</button>
        <button type="button" class="btn btn-default btn-next">Next</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Button trigger modal -->
<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal2">
  Player 2
</button>

<!-- Modal -->
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Modal title 2</h4>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default btn-prev">Prev</button>
        <button type="button" class="btn btn-default btn-next">Next</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<!-- Button trigger modal -->
<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal3">
  Player 3
</button>

<!-- Modal -->
<div class="modal fade" id="myModal3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Modal title 3</h4>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default btn-prev">Prev</button>
        <button type="button" class="btn btn-default btn-next">Next</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<!-- Button trigger modal -->
<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal4">
  Player 4
</button>

<!-- Modal -->
<div class="modal fade" id="myModal4" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Modal title 4</h4>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default btn-prev">Prev</button>
        <button type="button" class="btn btn-default btn-next">Next</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
</section>  

<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal1"> Button 1 </button>

<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal2"> Button 2 </button>

<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal3"> Button 1 </button>
<!-- Modal  Popup 1 -->
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
<h4 class="modal-title" id="myModalLabel">Modal title 1</h4>
</div>
<div class="modal-body">
Modal Popup 1
</div>
<div class="modal-footer">
<button type="button" class="btn btn-default btn-prev">Prev</button>
<button type="button" class="btn btn-default btn-next">Next</button>
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>

<!-- Modal  Popup 2 -->
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
<h4 class="modal-title" id="myModalLabel">Modal title 2</h4>
</div>
<div class="modal-body">
Modal Popup 2
</div>
<div class="modal-footer">
<button type="button" class="btn btn-default btn-prev">Prev</button>
<button type="button" class="btn btn-default btn-next">Next</button>
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>

<!-- Modal  Popup 3 -->
<div class="modal fade" id="myModal3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
<h4 class="modal-title" id="myModalLabel">Modal title 3</h4>
</div>
<div class="modal-body">
Modal Popup 3
</div>
<div class="modal-footer">
<button type="button" class="btn btn-default btn-prev">Prev</button>
<button type="button" class="btn btn-default btn-next">Next</button>
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>


<script>
jQuery("div[id^='myModal']").each(function(){
  
  var currentModal = jQuery(this);

  
  //click next
  currentModal.find('.btn-next').click(function(){
    currentModal.modal('hide');
    currentModal.closest("div[id^='myModal']").nextAll("div[id^='myModal']").first().modal('show'); 
  });
  
  //click prev
  currentModal.find('.btn-prev').click(function(){
    currentModal.modal('hide');
    currentModal.closest("div[id^='myModal']").prevAll("div[id^='myModal']").first().modal('show'); 
  });

});
</script>
<?php endwhile; // end of the loop. ?>	
<?php get_footer(); ?>

