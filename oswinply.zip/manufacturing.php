<?php
/**
 * Template Name: Manufacturing
 */


get_header(); ?>
<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>

<section class="bannersec">
  <div style="background-image:url('<?php echo $featureimg; ?>');background-size:cover;background-repeat:no-repeat;background-position:center;width:100%;height:310px;">
    <div class="caption-content">
      <h2 class="text-center"><?php echo the_title();?></h2>
    </div>
  </div>
</section>
<div class="page-crumbs">
  <div class="container">
    <?php custom_breadcrumbs(); ?>
  </div>
</div>
<section class="world-class">
<div class="container">
<h2><?php echo the_field('world-class');?></h2> 
<p><?php echo the_field('world-class-para');?></p>


</div>
</section>
<section class="core-commitment">
<div class="container">

<h2 class="text-center"><?php echo the_field('our-commit');?></h2>
<div>
<?php
if( have_rows('commit') ):
while ( have_rows('commit') ) : the_row(); ?> 
<div class="col-md-6 col-sm-6 col-xs-12 animated wow zoomIn">
<h3><?php echo the_sub_field('title');?></h3>
<p><?php echo the_sub_field('content');?></p>
</div>
<?php endwhile; endif; ?>
<div class="video">
<video controls width="60%" poster="<?php bloginfo('template_url'); ?>/inc/images/thumbnail.jpg" style="margin:0 auto;display:block;">
  <source src="<?php bloginfo('template_url'); ?>/inc/images/oswin-video.mp4" type="video/mp4">
  <source src="<?php bloginfo('template_url'); ?>/inc/images/oswin-video.ogg" type="video/ogg">
  </video>
  
</div>
</div>
</div>
</section>
<section class="manufacturing-process">
<div class="container">
<div class="process-set">
<?php echo the_field('process-one');?>
</div>
<div class="process-set">
<?php echo the_field('process-two');?>
</div>
<div class="process-set">
<?php echo the_field('process-three');?>
</div>
<div class="process-set">
<?php echo the_field('process-four');?>
</div>

</div>
<!--<div class="container">
<div class="process-set">
<div class="col-md-4 col-sm-4 col-xs-4">
<div class="process-out">
<div class="process">
<img src="<?php bloginfo('template_url')?>/inc/images/pro1.jpg"  />
</div>
</div>
<h2>1</h2>
<h3>Direct Procurement <br/>
of logs from local & <br/>
international markets </h3>
</div>
<div class="col-md-4 col-sm-4 col-xs-4">
<div class="process-out">
<div class="process mbg">
<img src="<?php bloginfo('template_url')?>/inc/images/pro2.jpg"  />
</div>
</div>
<h2>2</h2>
<h3>Logs go through chemical <br/>
treatment process that makes <br/>
it termite free & odour free </h3>
</div>
<div class="col-md-4 col-sm-4 col-xs-4">
<div class="process-out">
<div class="process bg-none">
<img src="<?php bloginfo('template_url')?>/inc/images/pro3.jpg"  />
</div>
</div>
<h2>3</h2>
<h3>Logs are then cut to<br/>
size through a veneer<br/>
peeling lathe </h3>
</div>
</div>
<div class="process-set">
<div class="col-md-4 col-sm-4 col-xs-4">
<div class="process-out">
<div class="process mbg">
<img src="<?php bloginfo('template_url')?>/inc/images/pro4.jpg"  />
</div>
</div>
<h2>4</h2>
<h3>Grading process of <br/>
veneer to ensure only <br/>
the best veneers are <br/>
used for oswin products  </h3>
</div>
<div class="col-md-4 col-sm-4 col-xs-4">
<div class="process-out">
<div class="process">
<img src="<?php bloginfo('template_url')?>/inc/images/pro5.jpg"  />
</div>
</div>
<h2>5</h2>
<h3>The veneers go through <br/>
a roller dryer that reduces <br/>
the moisture to < 6%, <br/>
surpassing ISI norms  </h3>
</div>
<div class="col-md-4 col-sm-4 col-xs-4">
<div class="process-out">
<div class="process bg-none mbg">
<img src="<?php bloginfo('template_url')?>/inc/images/pro6.jpg"  />
</div>
</div>
<h2>6</h2>
<h3>Assembly of ply by our assembly <br/> 
 experts to ensure  minimal core<br/> 
 gaps, & minimal thickness<br/> 
 variation, cross veneer assembly </h3>
</div>
</div>
<div class="process-set">
<div class="col-md-4 col-sm-4 col-xs-4">
<div class="process-out">
<div class="process">
<img src="<?php bloginfo('template_url')?>/inc/images/pro7.jpg"  />

</div>

</div>
<h2>7</h2>
<h3>Our unique Advanced Resin<br/>
Technology (ARTechnology) is <br/>
used to provide superior bonding</h3>
</div>
<div class="col-md-4 col-sm-4 col-xs-4">
<div class="process-out bg-curve">
<div class="process mbg">
<img src="<?php bloginfo('template_url')?>/inc/images/pro8.jpg"  />


</div>

</div>
<h2>8</h2>
<h3>Ply goes through<br/>
hydraulic press process</h3>
</div>
<div class="col-md-4 col-sm-4 col-xs-4">
<div class="process-out">
<div class="process bg-none">
<img src="<?php bloginfo('template_url')?>/inc/images/pro9.jpg"  />

</div>

</div>
<h2>9</h2>
<h3>Ply is then cut to size  </h3>
</div>
</div>
<div class="process-set">
<div class="col-md-4 col-sm-4 col-xs-4">
<div class="process-out">
<div class="process mbg">
<img src="<?php bloginfo('template_url')?>/inc/images/pro10.jpg"  />

</div>
</div>
<h2>10</h2>
<h3>Wide belt sanding for better <br/>
finishing and chemical treatment<br/>
process to make it termite <br/>
and borer free </h3>
</div>
<div class="col-md-4 col-sm-4 col-xs-4">
<div class="process-out">
<div class="process">
<img src="<?php bloginfo('template_url')?>/inc/images/pro11.jpg"  />


</div>

</div>
<h2>11</h2>
<h3>All ply is then gone through<br/>
an ISI inspection by our finishing<br/>
experts where defected<br/>
sheets are removed </h3>
</div>
<div class="col-md-4 col-sm-4 col-xs-4">
<div class="process-out">
<div class="process bg-none mbg">
<img src="<?php bloginfo('template_url')?>/inc/images/pro12.jpg"  />

</div>

</div>
<h2>12</h2>
<h3>Ply is loaded to truck <br/>
and dispatched </h3>
</div>
</div>

</div>-->
</section>
<?php endwhile; // end of the loop. ?>
<?php get_footer(); ?>
