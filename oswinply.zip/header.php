<?php

/**

 * The Header for our theme.

 *

 * Displays all of the <head> section and everything up till <div id="content">

 *

 * @package Oswinply

 */

?><!DOCTYPE html>

<html <?php language_attributes(); ?>>

<head>

<meta charset="<?php bloginfo( 'charset' ); ?>">

<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="viewport" content="width=device-width, initial-scale=1">

<!--<link rel="profile" href="https://gmpg.org/xfn/11">-->

<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/inc/css/slick.css">
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/inc/css/slick-theme.css">

<script src='https://www.google.com/recaptcha/api.js'></script>

<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>


<script>
$(function() {

    $('#row_dim').hide(); 

    $('#type').change(function(){

        if($('#type').val() == 'Product') {

            $('#row_dim').show(); 

			$('.testimonial').addClass('pad');

        } else {

            $('#row_dim').hide(); 

        } 

    });

});

$(function() {

    $('#row_dim2').hide(); 

    $('#type').change(function(){

        if($('#type').val() == 'Partnership') {

            $('#row_dim2').show(); 

			$('.testimonial').removeClass('pad1');

			$('.testimonial').removeClass('pad');

        } else {

            $('#row_dim2').hide(); 

        } 

    });

});

$(function() {

    $('#row_dim1').hide(); 

    $('#type').change(function(){

        if($('#type').val() == 'Careers') {

            $('#row_dim1').show(); 

			$('.testimonial').addClass('pad1');

        } else {

            $('#row_dim1').hide(); 

        } 

    });

});

$(function() {

    $('.row_dim_en').hide(); 

    $('.type').change(function(){

        if($('.type').val() == 'Product') {

            $('.row_dim_en').show(); 

		} else {

            $('.row_dim_en').hide(); 

        } 

    });

});



$(function() {

    $('.row_dim1_en').hide(); 

    $('.type').change(function(){

        if($('.type').val() == 'Careers') {

            $('.row_dim1_en').show(); 

			} else {

            $('.row_dim1_en').hide(); 

        } 

    });

});

</script>



<script src="<?php bloginfo('template_url'); ?>/inc/js/smoothproducts.min.js"></script>

<script src="<?php bloginfo('template_url'); ?>/inc/js/jquery-mTab-min.js"></script>

<script type="text/javascript">

$(document).ready(function(e) {

    $('.tabbing').mTab({

		 navigation: ".tabNav"

		,container: ".tabContainer"

		,activeTab: 1

		,activeClass: "active"

		,scrollOffset: true

		,accordScreen: 767

		,toggleClose: true

		,animation: false

		,openWithUrl: true

		,callbackonclick:  function() {  }

		,callback: function() {  }

	});

	

});



</script>

<script src="<?php bloginfo('template_url'); ?>/inc/js/slick.js"></script>

<script>



$(document).ready(function(){

    $('.customer-logos').slick({

        slidesToShow: 6,

        slidesToScroll: 1,

        autoplay: true,

        autoplaySpeed: 1500,

        arrows: true,

        dots: false,

        pauseOnHover: false,

        responsive: [{

            breakpoint: 768,

            settings: {

                slidesToShow: 3

            }

        }, {

            breakpoint: 480,

            settings: {

                slidesToShow: 2

            }

        }]

    });

});

// When the DOM is ready, run this function

$(document).ready(function() {

  //Set the carousel options

  $('#quote-carousel').carousel({

    pause: true,

	autoplay:true,

    interval: 2000,

  });

});

$(document).ready(function () {

      

    $("#myBtn").click(function(){

         $('#myModal').modal('show');

    });

});

$('.modal').on('hide.bs.modal', function (e) {

    $("element.style").css("padding-right","0");

});

</script>



<script type="text/javascript">

	/* wait for images to load */

	$(window).load(function() {

		$('.sp-wrap').smoothproducts();

	});

</script>



<style>

.intro{display:block}

</style>

<?php wp_head(); ?>



</head>



<body <?php body_class(); ?>>

<div id="page" class="hfeed site">



	<nav class="navbar navbar-default" role="navigation">

    <div class="headersec">

    

   <div class="container">

        

      

			<div class="navbar-header">

            <div id="logo">

            <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php bloginfo('template_url'); ?>/inc/images/logo.svg" alt="<?php bloginfo( 'name' ); ?>" width="190"/></a></div></div>

			 <div class="row">

            <div id="menu">

           <!-- end of #logo -->

            

            

            <div class="menuRight">

			<?php Oswinply_header_menu(); ?>

            

          <!--  <i class="fa fa-search"></i>-->

          

             </div>

        

				</div>

                </div>

			</div>

		

           </div> 

           

                 

		

	</nav><!-- .site-navigation -->





        <div class="top-section">

        <div class="enquirysec">

<button class="enquiry" data-toggle="modal" data-target="#myModal">

       <img src="<?php bloginfo('template_url');?>/inc/images/h-ico-enquiry.svg" />

    </button>

<!-- Modal -->

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

    <div class="modal-dialog">

        <div class="modal-content">

            <div class="modal-header">

                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

               

            </div>

            <div class="modal-body">

             <div class="formout">

<h3>Submit an Enquiry</h3>



<?php echo do_shortcode ('[contact-form-7 id="666" title="Enquiry"]')?>









</div>

            </div>

           

        </div>

    </div>

</div>

<div class="brochure"><a href="<?php bloginfo('template_url');?>/inc/pdf/Oswin_E-brochure.pdf" target="_blank"><img src="<?php bloginfo('template_url');?>/inc/images/h-ico-pdf.svg" /></a></div>

<div class="whatsapp"><a href="https://api.whatsapp.com/send?phone=919566290005"><img src="<?php bloginfo('template_url');?>/inc/images/h-ico-whatsapp.svg" /></a></div>

<div class="compare-icon"><a href="<?php echo get_site_url(); ?>/products/compare-plywoods/"><img src="<?php bloginfo('template_url');?>/inc/images/h-ico-compare.svg" /></a></div>

</div> 

		<?php Oswinply_featured_slider(); ?>

		<?php Oswinply_call_for_action(); ?>

        </div>

     



            <div class="container-fluid main-content-area">

              

