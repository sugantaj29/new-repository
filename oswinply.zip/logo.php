<?php
/**
 * Template Name: Client logo
 */


get_header(); ?>
 <?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>
	
<section class="bannersec">
    <div style="background-image:url(<?php echo $featureimg; ?>);background-size:cover;background-repeat:no-repeat;background-position:center;width:100%;height:310px;">
				
    <div class="caption-content">
    <h2 class="text-center"><?php the_title();?></h2>
    <p class="text-center"><?php echo the_field('paragraph')?></p>
    </div>
                
    </div>          
</section>
<div class="page-crumbs">
<div class="container">
<?php custom_breadcrumbs(); ?>
</div>
</div>
<section class="client-logo">
<div class="container">
<h2><?php echo the_field('client')?></h2>
<p class="text-center"><?php echo the_field('client-para')?></p>
<?php
if( have_rows('icon') ):
while ( have_rows('icon') ) : the_row(); ?>
<div class="logo wow animate zoomIn"><div class="logo-in"><img src="<?php echo the_sub_field('logo')?>" /></div></div>
<?php endwhile; endif; ?>
</div>

	
</section>


<?php endwhile; // end of the loop. ?>	
<?php get_footer(); ?>
