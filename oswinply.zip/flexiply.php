<?php
/**
 * Template Name: Flexiply
 */


get_header(); ?>
 <?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>
	
<section class="bannersec">
    <div style="background-image:url(<?php echo $featureimg; ?>);background-size:cover;background-repeat:no-repeat;background-position:center;width:100%;height:310px;">
				
    <div class="caption-content">
    <h2 class="text-center"><?php echo the_field('title')?></h2>
    <p class="text-center"><?php echo the_field('paragraph')?></p>
    </div>
                
    </div>          
</section>
<div class="page-crumbs">
<div class="container">
<?php custom_breadcrumbs(); ?>
</div>
</div>
<section class="marine-grade-plywoods">
<div class="container">
<div class="col-md-3 col-sm-3 col-xs-12">
<div class="sidebar">
<h3>Products</h3>
 <?php wp_nav_menu(array('menu'=>'primary-product-menu'));?>        
 <a href="<?php echo the_field('compare-link')?>" class="compare">Compare PLYWOODS</a>
</div>
</div>
<div class="col-md-5 col-sm-9 col-xs-12">
<div class="marine-grade">
<h2><?php echo the_field('marine-title')?></h2>
<p><?php echo the_field('content')?></p>

<div class="icons">
 <?php
if( have_rows('icon-one') ):
while ( have_rows('icon-one') ) : the_row(); ?>
<div class="icon-in animated wow zoomIn"><img src="<?php echo the_sub_field('icon')?>" />
<h4><?php echo the_sub_field('title')?></h4>
</div>
 <?php endwhile; endif; ?>

</div>
<!--<h3><?php echo the_field('tech-title')?></h3>
<?php echo the_field('specification')?>-->

</div>
</div>
<div class="col-md-4 col-sm-12 col-xs-12">
<div class="ply-wood-img pull-right">
<div class="sp-loading"><img src="<?php bloginfo('template_url'); ?>/inc/images/sp-loading.gif" alt=""><br>LOADING IMAGES</div>
		<div class="sp-wrap">
         <?php
if( have_rows('plywood-img') ):
while ( have_rows('plywood-img') ) : the_row(); ?>
<a href="<?php echo the_sub_field('small')?>"><img src="<?php echo the_sub_field('big')?>" alt=""></a>
 <?php endwhile; endif; ?>
			
		</div></div>
</div>
</div>
</section>
<section class="oswinply">
<div class="container">
<div class="tabbing">
  <ul class="tabNav">
  <?php
        if( have_rows('tab-title') ):
		 $i=0; 
        while ( have_rows('tab-title') ) : the_row(); ?>
    <li><a href="#tab1<?php echo $i; ?>"><?php echo the_sub_field('title')?>  </a></li>
    <?php $i++; 
   endwhile; endif; ?>
  
  </ul>
  
  <div class="tabContainer">
  <?php
        if( have_rows('tabcontent') ):
		$i=0;  
        while ( have_rows('tabcontent') ) : the_row(); ?>
    <div class="tabContent" id="tab1<?php echo $i; ?>">
   <div class="col-md-8 col-sm-8 col-xs-12">
   <div class="content">
      <h3><?php echo the_sub_field('title')?></h3>
      <p><?php echo the_sub_field('content')?></p>
   </div>
   </div>
   <div class="col-md-4 col-sm-4 col-xs-12">
   <img  src="<?php echo the_sub_field('image')?>" />
   </div>
    </div>
     <?php $i++; 
   endwhile; endif; ?>
  
    
  </div>
</div>
</div>
</section>


<?php endwhile; // end of the loop. ?>	
<?php get_footer(); ?>
