<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Oswinply
 */
?>
               
            </div><!-- close .container -->
       
	<div id="footer-area">
		<div class="container footer-inner">
			<?php get_sidebar( 'footer' ); ?>
		</div>

		<footer id="colophon" class="site-footer" role="contentinfo">
			<div class="site-info container">
				
				<nav role="navigation" class="col-md-5 col-sm-6 col-xs-12">
					<h4>Products</h4>
                    <h5>Plywoods</h5>
                    
                    <div class="col-md-11 col-sm-12 col-xs-12">
					<?php wp_nav_menu(array('menu'=>'products'));?>
                    <div class="plft"><?php wp_nav_menu(array('menu'=>'product-set-two'));?></div>
                    </div>
                    <!--<div class="plft">
                     <div class="col-sm-6 col-xs-6">
                    
                    </div>
                    </div>-->
				</nav>
                <nav role="navigation" class="col-md-3 col-sm-3 col-xs-6">
					<h4>Discover Oswin Ply</h4>
					<?php wp_nav_menu(array('menu'=>'discover'));?>
				</nav>
                <div class="col-md-3 col-sm-3 col-xs-12">
                <div class="corporate">
                <h3>Corporate Office</h3>
                <p>183/1, Sydenhams Road, Apparao Garden, <br/>
                Choolai, Chennai - 600 112 <br/>
                Ph: +91-44-2669 0023  |  +91-44-2669 0156 <br/>
                <span>Email: <a href="mailto:enquiry@oswinply.com">enquiry@oswinply.com </a> </span>
                 </p>
                </div>
                </div>
				<div class="copyright">
                <div class="col-md-6 col-sm-6 col-xs-12">
					&copy;  <script type="text/javascript">
var now = new Date();
var d = now.getFullYear();
document.write(d);</script> Oswin Ply Limited. All rights reserved.
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                      <div class="social-icon">
                <ul>
                   <li><a href="https://www.facebook.com/oswinply/" class="fb" target="_blank"><i class="fa fa-facebook"></i></a></li>
                   <li><a href="https://twitter.com/oswinplywood" class="tw" target="_blank"><i class="fa fa-twitter"></i></a></li>
                   <li><a href="https://www.linkedin.com/company/oswinply" class="in" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                   <li><a href="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3886.123431323992!2d80.26690131482329!3d13.091362990777391!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a5265fa45e6d001%3A0xf2801144c0922f57!2sOswin+Wood+Panels+Pvt.Ltd!5e0!3m2!1sen!2sin!4v1544007223302"  class="lt"  target="_blank"><i class="fa fa-map-marker"></i></a></li>

                   </ul>
                  
                   </div>
                    </div>
					
				</div>
			</div><!-- .site-info -->
            
            <div class="btm_enquirysec">

		<button class="enquiry" data-toggle="modal" data-target="#myModal1">

        <img src="<?php bloginfo('template_url');?>/inc/images/h-ico-enquiry.svg" />

    	</button>

<!-- Modal -->

<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

    <div class="modal-dialog">

        <div class="modal-content">

            <div class="modal-header">

                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

               

            </div>

            <div class="modal-body">

             <div class="formout">

			<h3>Submit an Enquiry</h3>

			<?php echo do_shortcode ('[contact-form-7 id="666" title="Enquiry"]')?>

			</div>

            </div>

           

        </div>

    </div>

</div>







</div>
            <div class="bottom"> <a href="<?php echo the_field('compare-link')?>" class="f-compare">Compare PLYWOODS</a></div>

			<div class="scroll-to-top"><i class="fa fa-angle-up"></i></div><!-- .scroll-to-top -->
		</footer><!-- #colophon -->
	</div>
</div><!-- #page -->

<?php wp_footer(); ?>
<!--<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/inc/css/flexslider.css">

<script src="<?php bloginfo('template_url'); ?>/inc/js/flexslider.min.js"></script>
<script type="text/javascript">
// Can also be used with $(document).ready()
jQuery('.flexslider').flexslider({
  pauseOnAction: true, // default setting
  after: function(slider) {
  /* auto-restart player if paused after action */
  if (!slider.playing) {
    slider.play();
  }
 }
});
</script>-->
<script src="<?php bloginfo('template_url'); ?>/inc/js/wow.min.js" type="text/javascript"></script>
<script>
	new WOW().init();
</script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-132063618-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-132063618-1');
</script>
<script>
var gs_sid = '1ooBdX0cgtk155ww9MmdMTw8kDavIy5J1m76VwSrcTSs'; // Enter your Google Sheet ID here
var gs_clid = '661380405158-h6esq9jnqbdrnovm5hhtoaoh81oc88ai.apps.googleusercontent.com'; // Enter your API Client ID here
var gs_clis = 'eRQ--oX4Ndbm6skmEpC1cUz5'; // Enter your API Client Secret here
var gs_rtok = '1/Bd0UPcdw0gFmKc0fAsqNad78C2jm6JsURHozJHelx6c'; // Enter your OAuth Refresh Token here
</script>
</body>
</html>