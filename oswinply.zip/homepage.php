<?php
/**
 * Template Name: Home Page
 */


get_header(); ?>

<section class="bannersec" style="">
  <div class="flexslider">
  <ul class="slides">
 <?php
            $args = array( 'posts_per_page' => 5,'post_type' =>'home_banner','post_status'=> 'publish','orderby' => 'date','order' => 'ASC');
            $bannerposts = get_posts( $args );
            foreach ( $bannerposts as $bpost ) : setup_postdata( $bpost );
            $bannerimg = wp_get_attachment_url( get_post_thumbnail_id($bpost->ID) );
		        $custom=get_post_custom($bpost->ID);
				$phoneimg = wp_get_attachment_url( $custom['phone'][0]);
           
           ?>
     <li>
<div class="banner" style="background-image:url(<?php echo $bannerimg; ?>);">
      <div class="caption">
        <h2 class="text-center"> <?php echo $custom['title'][0];?></h2>
        <p><?php echo $custom['content'][0];?></p>
       
    </div></div>
    <div class="m-banner" style="background-image:url(<?php echo $phoneimg; ?>);background-size:120%;background-repeat:no-repeat;background-position:center;width:100%;height:400px;">
      <div class="caption">
        <h2 class="text-center"> <?php echo $custom['title'][0];?></h2>
        <p><?php echo $custom['content'][0];?></p>
       
    </div></div>
    </li>
    <?php endforeach; 
            wp_reset_postdata();?></li>
      
  </ul>
  </div>
</section>
<div class='popup'>
<div class='cnt223'>
<div class="formout">
<a href='' class='close-btn'>x</a>
<h3>Submit an Enquiry</h3>
<div class="index_form">
<?php echo do_shortcode ('[contact-form-7 id="510" title="popup"]')?>
</div>
</div>

</p>
</div>
</div>

<section class="home-products">
<div class="container">
 <?php
        if( have_rows('products') ):
        while ( have_rows('products') ) : the_row(); ?>
<div class="col-md-4 col-sm-4 col-xs-12 wow animated zoomIn">
<div class="products-list">
<h3><?php the_sub_field('title');?></h3>
<p><?php the_sub_field('content');?></p>
<a href="<?php the_sub_field('link');?>">Explore</a>
</div>
</div>
 <?php endwhile; endif; ?>

</div>




<div class="view">
<a href="<?php echo get_site_url();?>/products/plywood/oswin-club/">View All Products</a>
</div>
</div>
</section>

<section class="plywood">
<div class="container">
<div class="col-md-6 col-sm-12 col-xs-12 wow animated fadeInLeft">
<div class="quality">
<h2><?php the_field('quality');?></h2>
<p><?php the_field('quality-para');?></p>
<a href="<?php the_field('quality-link');?>">Explore</a>
</div>
</div>
<div class="col-md-6 col-sm-12 col-xs-12 wow animated fadeInRight">
<div class="accrediations">
<h3><?php the_field('accrediation-title');?></h3>
<ul>
 <?php
        if( have_rows('accrediation-logo') ):
        while ( have_rows('accrediation-logo') ) : the_row(); ?>
<li><img src="<?php the_sub_field('logo');?>" alt="" /></li>
 <?php endwhile; endif; ?>
</ul>
</div>
</div>
</div>
</section>

<section class="our-clients">
<div class="container">
<h3><?php the_field('clients');?></h3>
<div class="customer-logos slider">
	<?php
        if( have_rows('our-clients') ):
        while ( have_rows('our-clients') ) : the_row(); ?>
      <div class="slide"><img src="<?php the_sub_field('logo');?>" alt="" /></div>
      <?php endwhile; endif; ?>
      
   </div>
</div>
</section>

<section class="last-section">
<div class="col-md-12 col-sm-12 col-xs-12">
<div class="testimonial">
<img src="<?php bloginfo('template_url'); ?>/inc/images/quote.png" alt="" />
<h3>Testimonials</h3>
<div class="carousel slide" data-ride="carousel" id="quote-carousel" style="margin:-40px 0 0">
        <!-- Bottom Carousel Indicators -->
        <ol class="carousel-indicators">
          <li data-target="#quote-carousel" data-slide-to="0" class="active"></li>
          <li data-target="#quote-carousel" data-slide-to="1"></li>
          <li data-target="#quote-carousel" data-slide-to="2"></li>
          <li data-target="#quote-carousel" data-slide-to="3"></li>
        </ol>
        
        <!-- Carousel Slides / Quotes -->
        <div class="carousel-inner">
        
          <?php the_field('slider-testimonial')?>
        </div>
        
        
    
  
      </div>               
    </div>
</div>

<div class="col-md-6 col-sm-6 col-xs-12" style="display:none">
<div class="formout">
<h3>Submit an Enquiry</h3>
<div class="index_form">
<?php echo do_shortcode ('[contact-form-7 id="5" title="Home Form"]')?>
</div>
</div>
</div>
</section>

    
<script type='text/javascript'>
jQuery(function(){
var overlay = $('<div id="overlay"></div>');
overlay.show();
overlay.appendTo(document.body);
jQuery('.popup').show();
jQuery('.close-btn').click(function(){
jQuery('.popup').hide();
overlay.appendTo(document.body).remove();
return false;
});
jQuery('.x').click(function(){
jQuery('.popup').hide();
overlay.appendTo(document.body).remove();
return false;
});
});
</script>  

  
   
<?php get_footer(); ?>

