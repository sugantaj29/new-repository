<?php
/**
 * The template for displaying 404 pages (Not Found).
 *
 * @package Oswinply
 */

get_header(); ?>


<section class="bannersec" style="">
    <div style="background:#00a859;background-size:cover;background-repeat:no-repeat;background-position:center;width:100%;height:200px;">
				
            	    <div class="caption-content">
                    <h2 class="text-center">404</h2>
                    
                    
				  </div>
                  </div>
</section>
		
				<section class="error-404 not-found">
                <div class="container">

					<h1 class="text-center">404 Page Not Found</h1>
					<p class="text-center">The page has either moved or not available anymore. You can continue browsing by clicking on the links on top. Thank you!</p>
</div>
					<!-- .page-content -->
				</section><!-- .error-404 -->

			

<style type="text/css">
	section.error-404.not-found {
    padding: 150px 0px;
    text-align: center;
	float:left;
	width:100%;
}
.error-404 h1{color:#333;font-family: 'ProximaNova-Bold';}
.error-404 p{font-family: 'ProximaNova-Regular';}
.caption-content{padding-top:65px}
</style>

<?php get_footer(); ?>