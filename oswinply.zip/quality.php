<?php
/**
 * Template Name: Quality
 */


get_header(); ?>
 <?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>
	
<section class="bannersec">
    <div style="background-image:url(<?php echo $featureimg; ?>);background-size:cover;background-repeat:no-repeat;background-position:center;width:100%;height:310px;">
				
    <div class="caption-content">
    <h2 class="text-center"><?php echo the_title();?></h2>
    <p class="text-center"><?php echo the_field('paragraph')?>    </p>
    </div>
                
    </div>          
</section>
<div class="page-crumbs">
<div class="container">
<?php custom_breadcrumbs(); ?>
</div>
</div>

<section class="hitting">
<div class="container">
<div class="col-md-5 col-sm-5 col-xs-12">
<h2><?php echo the_field('hitting-title')?>  </h2>
<h3><?php echo the_field('hitting-content')?>  </h3>
<p><?php echo the_field('hitting-para')?>  </p>
</div>
<div class="col-md-7 col-sm-7 col-xs-12 wow animated zoomIn"><img src="<?php echo the_field('hitting-img')?>" /></div>
</div>
</section>
<section class="proof-quality">
<div class="container">
<div class="col-md-6 col-sm-6 col-xs-12" style="background:url('<?php echo the_field('proof-img')?>') no-repeat;background-size:cover;min-height:425px;">

</div>
<div class="col-md-6 col-sm-6 col-xs-12">
<h2><?php echo the_field('proof-title')?></h2>
<p><?php echo the_field('proof-content')?></p>
</div>
</div>
</section>

<section class="advance">
<div class="container">
<h2><?php echo the_field('advance-title')?></h2>
<?php
if( have_rows('advance') ):
while ( have_rows('advance') ) : the_row(); ?> 
<div class="col-md-4 col-sm-6 col-xs-6 wow animated fadeIn">
<div class="adv-box">
<h3><?php echo the_sub_field('title')?></h3>
<p><?php echo the_sub_field('content')?></p>
</div>
</div>
<?php endwhile; endif; ?>



</div>
<div class="container">
<?php
if( have_rows('advance-image') ):
while ( have_rows('advance-image') ) : the_row(); ?> 
<div class="col-md-4 col-sm-4 col-xs-4 wow animated zoomIn">
<div class="adv-imgset-box">
<img src="<?php echo the_sub_field('image')?>" class="img-responsive"/></div>
</div>
<?php endwhile; endif; ?>


</div>
</section>



<?php endwhile; // end of the loop. ?>	
<?php get_footer(); ?>
