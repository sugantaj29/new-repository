<?php
/**
 * Template Name: About
 */


get_header(); ?>
<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>

<section class="bannersec">
  <div style="background-image:url('<?php echo $featureimg; ?>');background-size:cover;background-repeat:no-repeat;background-position:center;width:100%;height:310px;">
    <div class="caption-content">
      <h2 class="text-center"><?php echo the_title();?></h2>
    </div>
  </div>
</section>
<div class="page-crumbs">
  <div class="container">
    <?php custom_breadcrumbs(); ?>
  </div>
</div>
<section class="world-class">
<div class="container">
<h2><?php echo the_field('world-class');?></h2> 
<p><?php echo the_field('world-class-para');?></p>

</div>
</section>
<section class="core-commitment">
<div class="container">
<h2 class="text-center"><?php echo the_field('our-commit');?></h2>
<div>
<?php
if( have_rows('commit') ):
while ( have_rows('commit') ) : the_row(); ?> 
<div class="col-md-6 col-sm-6 col-xs-12 animated wow zoomIn">
<h3><?php echo the_sub_field('title');?></h3>
<p><?php echo the_sub_field('content');?></p>
</div>
<?php endwhile; endif; ?>
</div>

</div>
</section>
<section class="production">
<div class="container">
<div class="col-md-6 col-sm-6 col-xs-12 animated wow fadeInUp">
<?php
if( have_rows('production') ):
while ( have_rows('production') ) : the_row(); ?> 
<h3><?php echo the_sub_field('title');?></h3>
<p><?php echo the_sub_field('content');?></p>
<?php endwhile; endif; ?>
</div>
<div class="col-md-6 col-sm-6 col-xs-12">
<div class="we-guarantee">
<h3><?php echo the_field('guarantee-title');?></h3>
<h4><?php echo the_field('percent');?></h4>
<ul>
<?php
if( have_rows('guarantee') ):
while ( have_rows('guarantee') ) : the_row(); ?> 
<li class="animated wow fadeIn"><?php echo the_sub_field('list');?></li>
<?php endwhile; endif; ?>
</ul>
</div>
</div>
</div>
</section>
<?php endwhile; // end of the loop. ?>
<?php get_footer(); ?>
